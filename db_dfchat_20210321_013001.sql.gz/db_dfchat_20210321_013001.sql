-- MySQL dump 10.13  Distrib 5.6.50, for Linux (x86_64)
--
-- Host: localhost    Database: dfchat
-- ------------------------------------------------------
-- Server version	5.6.50-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `df_admin_access`
--

DROP TABLE IF EXISTS `df_admin_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_admin_access` (
  `module` varchar(16) NOT NULL DEFAULT '' COMMENT '模型名称',
  `group` varchar(16) NOT NULL DEFAULT '' COMMENT '权限分组标识',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `nid` varchar(16) NOT NULL DEFAULT '' COMMENT '授权节点id',
  `tag` varchar(16) NOT NULL DEFAULT '' COMMENT '分组标签'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='统一授权表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_admin_access`
--

LOCK TABLES `df_admin_access` WRITE;
/*!40000 ALTER TABLE `df_admin_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `df_admin_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_admin_action`
--

DROP TABLE IF EXISTS `df_admin_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_admin_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(16) NOT NULL DEFAULT '' COMMENT '所属模块名',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` varchar(80) NOT NULL DEFAULT '' COMMENT '行为标题',
  `remark` varchar(128) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COMMENT='系统行为表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_admin_action`
--

LOCK TABLES `df_admin_action` WRITE;
/*!40000 ALTER TABLE `df_admin_action` DISABLE KEYS */;
INSERT INTO `df_admin_action` VALUES (1,'user','user_add','添加用户','添加用户','','[user|get_nickname] 添加了用户：[record|get_nickname]',1,1480156399,1480163853),(2,'user','user_edit','编辑用户','编辑用户','','[user|get_nickname] 编辑了用户：[details]',1,1480164578,1480297748),(3,'user','user_delete','删除用户','删除用户','','[user|get_nickname] 删除了用户：[details]',1,1480168582,1480168616),(4,'user','user_enable','启用用户','启用用户','','[user|get_nickname] 启用了用户：[details]',1,1480169185,1480169185),(5,'user','user_disable','禁用用户','禁用用户','','[user|get_nickname] 禁用了用户：[details]',1,1480169214,1480170581),(6,'user','user_access','用户授权','用户授权','','[user|get_nickname] 对用户：[record|get_nickname] 进行了授权操作。详情：[details]',1,1480221441,1480221563),(7,'user','role_add','添加角色','添加角色','','[user|get_nickname] 添加了角色：[details]',1,1480251473,1480251473),(8,'user','role_edit','编辑角色','编辑角色','','[user|get_nickname] 编辑了角色：[details]',1,1480252369,1480252369),(9,'user','role_delete','删除角色','删除角色','','[user|get_nickname] 删除了角色：[details]',1,1480252580,1480252580),(10,'user','role_enable','启用角色','启用角色','','[user|get_nickname] 启用了角色：[details]',1,1480252620,1480252620),(11,'user','role_disable','禁用角色','禁用角色','','[user|get_nickname] 禁用了角色：[details]',1,1480252651,1480252651),(12,'user','attachment_enable','启用附件','启用附件','','[user|get_nickname] 启用了附件：附件ID([details])',1,1480253226,1480253332),(13,'user','attachment_disable','禁用附件','禁用附件','','[user|get_nickname] 禁用了附件：附件ID([details])',1,1480253267,1480253340),(14,'user','attachment_delete','删除附件','删除附件','','[user|get_nickname] 删除了附件：附件ID([details])',1,1480253323,1480253323),(15,'admin','config_add','添加配置','添加配置','','[user|get_nickname] 添加了配置，[details]',1,1480296196,1480296196),(16,'admin','config_edit','编辑配置','编辑配置','','[user|get_nickname] 编辑了配置：[details]',1,1480296960,1480296960),(17,'admin','config_enable','启用配置','启用配置','','[user|get_nickname] 启用了配置：[details]',1,1480298479,1480298479),(18,'admin','config_disable','禁用配置','禁用配置','','[user|get_nickname] 禁用了配置：[details]',1,1480298506,1480298506),(19,'admin','config_delete','删除配置','删除配置','','[user|get_nickname] 删除了配置：[details]',1,1480298532,1480298532),(20,'admin','database_export','备份数据库','备份数据库','','[user|get_nickname] 备份了数据库：[details]',1,1480298946,1480298946),(21,'admin','database_import','还原数据库','还原数据库','','[user|get_nickname] 还原了数据库：[details]',1,1480301990,1480302022),(22,'admin','database_optimize','优化数据表','优化数据表','','[user|get_nickname] 优化了数据表：[details]',1,1480302616,1480302616),(23,'admin','database_repair','修复数据表','修复数据表','','[user|get_nickname] 修复了数据表：[details]',1,1480302798,1480302798),(24,'admin','database_backup_delete','删除数据库备份','删除数据库备份','','[user|get_nickname] 删除了数据库备份：[details]',1,1480302870,1480302870),(25,'admin','hook_add','添加钩子','添加钩子','','[user|get_nickname] 添加了钩子：[details]',1,1480303198,1480303198),(26,'admin','hook_edit','编辑钩子','编辑钩子','','[user|get_nickname] 编辑了钩子：[details]',1,1480303229,1480303229),(27,'admin','hook_delete','删除钩子','删除钩子','','[user|get_nickname] 删除了钩子：[details]',1,1480303264,1480303264),(28,'admin','hook_enable','启用钩子','启用钩子','','[user|get_nickname] 启用了钩子：[details]',1,1480303294,1480303294),(29,'admin','hook_disable','禁用钩子','禁用钩子','','[user|get_nickname] 禁用了钩子：[details]',1,1480303409,1480303409),(30,'admin','menu_add','添加节点','添加节点','','[user|get_nickname] 添加了节点：[details]',1,1480305468,1480305468),(31,'admin','menu_edit','编辑节点','编辑节点','','[user|get_nickname] 编辑了节点：[details]',1,1480305513,1480305513),(32,'admin','menu_delete','删除节点','删除节点','','[user|get_nickname] 删除了节点：[details]',1,1480305562,1480305562),(33,'admin','menu_enable','启用节点','启用节点','','[user|get_nickname] 启用了节点：[details]',1,1480305630,1480305630),(34,'admin','menu_disable','禁用节点','禁用节点','','[user|get_nickname] 禁用了节点：[details]',1,1480305659,1480305659),(35,'admin','module_install','安装模块','安装模块','','[user|get_nickname] 安装了模块：[details]',1,1480307558,1480307558),(36,'admin','module_uninstall','卸载模块','卸载模块','','[user|get_nickname] 卸载了模块：[details]',1,1480307588,1480307588),(37,'admin','module_enable','启用模块','启用模块','','[user|get_nickname] 启用了模块：[details]',1,1480307618,1480307618),(38,'admin','module_disable','禁用模块','禁用模块','','[user|get_nickname] 禁用了模块：[details]',1,1480307653,1480307653),(39,'admin','module_export','导出模块','导出模块','','[user|get_nickname] 导出了模块：[details]',1,1480307682,1480307682),(40,'admin','packet_install','安装数据包','安装数据包','','[user|get_nickname] 安装了数据包：[details]',1,1480308342,1480308342),(41,'admin','packet_uninstall','卸载数据包','卸载数据包','','[user|get_nickname] 卸载了数据包：[details]',1,1480308372,1480308372),(42,'admin','system_config_update','更新系统设置','更新系统设置','','[user|get_nickname] 更新了系统设置：[details]',1,1480309555,1480309642);
/*!40000 ALTER TABLE `df_admin_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_admin_attachment`
--

DROP TABLE IF EXISTS `df_admin_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_admin_attachment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '文件名',
  `module` varchar(32) NOT NULL DEFAULT '' COMMENT '模块名，由哪个模块上传的',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '文件路径',
  `thumb` varchar(255) NOT NULL DEFAULT '' COMMENT '缩略图路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '文件链接',
  `mime` varchar(128) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `ext` char(8) NOT NULL DEFAULT '' COMMENT '文件类型',
  `size` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT 'sha1 散列值',
  `driver` varchar(16) NOT NULL DEFAULT 'local' COMMENT '上传驱动',
  `download` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `width` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '图片宽度',
  `height` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '图片高度',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='附件表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_admin_attachment`
--

LOCK TABLES `df_admin_attachment` WRITE;
/*!40000 ALTER TABLE `df_admin_attachment` DISABLE KEYS */;
INSERT INTO `df_admin_attachment` VALUES (1,1,'3ef2890392d25883755feb9cc2d3582dd9f82cc810540a-4Gx6Og.png','admin','uploads/images/20210224/d2a132d8c4d3f8586188ed09f5903b6e.png','','','image/png','png',1070090,'d3455f9d1cc8e1a2983a77fd29b04513','3ef2890392d25883755feb9cc2d3582dd9f82cc8','local',0,1614168321,1614168321,100,1,990,1000),(2,1,'logo.png','admin','uploads/images/20210224/f04e0ca877a51f57e923f3929c6e26d4.png','','','image/png','png',9389,'c43108af5bd37bbed5989f020506aa84','e49977673f3f408b91c660fc013ee6aa8c7ce6d2','local',0,1614168332,1614168332,100,1,282,282);
/*!40000 ALTER TABLE `df_admin_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_admin_config`
--

DROP TABLE IF EXISTS `df_admin_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_admin_config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '标题',
  `group` varchar(32) NOT NULL DEFAULT '' COMMENT '配置分组',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '类型',
  `value` text NOT NULL COMMENT '配置值',
  `options` text NOT NULL COMMENT '配置项',
  `tips` varchar(256) NOT NULL DEFAULT '' COMMENT '配置提示',
  `ajax_url` varchar(256) NOT NULL DEFAULT '' COMMENT '联动下拉框ajax地址',
  `next_items` varchar(256) NOT NULL DEFAULT '' COMMENT '联动下拉框的下级下拉框名，多个以逗号隔开',
  `param` varchar(32) NOT NULL DEFAULT '' COMMENT '联动下拉框请求参数名',
  `format` varchar(32) NOT NULL DEFAULT '' COMMENT '格式，用于格式文本',
  `table` varchar(32) NOT NULL DEFAULT '' COMMENT '表名，只用于快速联动类型',
  `level` tinyint(2) unsigned NOT NULL DEFAULT '2' COMMENT '联动级别，只用于快速联动类型',
  `key` varchar(32) NOT NULL DEFAULT '' COMMENT '键字段，只用于快速联动类型',
  `option` varchar(32) NOT NULL DEFAULT '' COMMENT '值字段，只用于快速联动类型',
  `pid` varchar(32) NOT NULL DEFAULT '' COMMENT '父级id字段，只用于快速联动类型',
  `ak` varchar(32) NOT NULL DEFAULT '' COMMENT '百度地图appkey',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态：0禁用，1启用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COMMENT='系统配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_admin_config`
--

LOCK TABLES `df_admin_config` WRITE;
/*!40000 ALTER TABLE `df_admin_config` DISABLE KEYS */;
INSERT INTO `df_admin_config` VALUES (1,'web_site_status','站点开关','base','switch','1','','站点关闭后将不能访问，后台可正常登录','','','','','',2,'','','','',1475240395,1477403914,1,1),(2,'web_site_title','站点标题','base','text','dfchat','','调用方式：<code>config(\'web_site_title\')</code>','','','','','',2,'','','','',1475240646,1477710341,2,1),(3,'web_site_slogan','站点标语','base','text','极简、极速、极致','','站点口号，调用方式：<code>config(\'web_site_slogan\')</code>','','','','','',2,'','','','',1475240994,1477710357,3,1),(4,'web_site_logo','站点LOGO','base','image','1','','','','','','','',2,'','','','',1475241067,1475241067,4,1),(5,'web_site_description','站点描述','base','textarea','','','网站描述，有利于搜索引擎抓取相关信息','','','','','',2,'','','','',1475241186,1475241186,6,1),(6,'web_site_keywords','站点关键词','base','text','dfchat','','网站搜索引擎关键字','','','','','',2,'','','','',1475241328,1475241328,7,1),(7,'web_site_copyright','版权信息','base','text','Copyright © 2021 All rights reserved.','','调用方式：<code>config(\'web_site_copyright\')</code>','','','','','',2,'','','','',1475241416,1477710383,8,1),(8,'web_site_icp','备案信息','base','text','','','调用方式：<code>config(\'web_site_icp\')</code>','','','','','',2,'','','','',1475241441,1477710441,9,1),(9,'web_site_statistics','站点统计','base','textarea','','','网站统计代码，支持百度、Google、cnzz等，调用方式：<code>config(\'web_site_statistics\')</code>','','','','','',2,'','','','',1475241498,1477710455,10,1),(10,'config_group','配置分组','system','array','base:基本\r\nsystem:系统\r\nupload:上传\r\ndevelop:开发\r\ndatabase:数据库','','','','','','','',2,'','','','',1475241716,1477649446,100,1),(11,'form_item_type','配置类型','system','array','text:单行文本\r\ntextarea:多行文本\r\nstatic:静态文本\r\npassword:密码\r\ncheckbox:复选框\r\nradio:单选按钮\r\ndate:日期\r\ndatetime:日期+时间\r\nhidden:隐藏\r\nswitch:开关\r\narray:数组\r\nselect:下拉框\r\nlinkage:普通联动下拉框\r\nlinkages:快速联动下拉框\r\nimage:单张图片\r\nimages:多张图片\r\nfile:单个文件\r\nfiles:多个文件\r\nueditor:UEditor 编辑器\r\nwangeditor:wangEditor 编辑器\r\neditormd:markdown 编辑器\r\nckeditor:ckeditor 编辑器\r\nicon:字体图标\r\ntags:标签\r\nnumber:数字\r\nbmap:百度地图\r\ncolorpicker:取色器\r\njcrop:图片裁剪\r\nmasked:格式文本\r\nrange:范围\r\ntime:时间','','','','','','','',2,'','','','',1475241835,1495853193,100,1),(12,'upload_file_size','文件上传大小限制','upload','text','0','','0为不限制大小，单位：kb','','','','','',2,'','','','',1475241897,1477663520,100,1),(13,'upload_file_ext','允许上传的文件后缀','upload','tags','doc,docx,xls,xlsx,ppt,pptx,pdf,wps,txt,rar,zip,gz,bz2,7z','','多个后缀用逗号隔开，不填写则不限制类型','','','','','',2,'','','','',1475241975,1477649489,100,1),(14,'upload_image_size','图片上传大小限制','upload','text','0','','0为不限制大小，单位：kb','','','','','',2,'','','','',1475242015,1477663529,100,1),(15,'upload_image_ext','允许上传的图片后缀','upload','tags','gif,jpg,jpeg,bmp,png','','多个后缀用逗号隔开，不填写则不限制类型','','','','','',2,'','','','',1475242056,1477649506,100,1),(16,'list_rows','分页数量','system','number','20','','每页的记录数','','','','','',2,'','','','',1475242066,1476074507,101,1),(17,'system_color','后台配色方案','system','radio','default','default:Default\r\namethyst:Amethyst\r\ncity:City\r\nflat:Flat\r\nmodern:Modern\r\nsmooth:Smooth','','','','','','',2,'','','','',1475250066,1477316689,102,1),(18,'develop_mode','开发模式','develop','radio','1','0:关闭\r\n1:开启','','','','','','',2,'','','','',1476864205,1476864231,100,1),(19,'app_trace','显示页面Trace','develop','radio','0','0:否\r\n1:是','','','','','','',2,'','','','',1476866355,1476866355,100,1),(21,'data_backup_path','数据库备份根路径','database','text','../data/','','路径必须以 / 结尾','','','','','',2,'','','','',1477017745,1477018467,100,1),(22,'data_backup_part_size','数据库备份卷大小','database','text','20971520','','该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M','','','','','',2,'','','','',1477017886,1477017886,100,1),(23,'data_backup_compress','数据库备份文件是否启用压缩','database','radio','1','0:否\r\n1:是','压缩备份文件需要PHP环境支持 <code>gzopen</code>, <code>gzwrite</code>函数','','','','','',2,'','','','',1477017978,1477018172,100,1),(24,'data_backup_compress_level','数据库备份文件压缩级别','database','radio','9','1:最低\r\n4:一般\r\n9:最高','数据库备份文件的压缩级别，该配置在开启压缩时生效','','','','','',2,'','','','',1477018083,1477018083,100,1),(25,'top_menu_max','顶部导航模块数量','system','text','10','','设置顶部导航默认显示的模块数量','','','','','',2,'','','','',1477579289,1477579289,103,1),(26,'web_site_logo_text','站点LOGO文字','base','image','2','','','','','','','',2,'','','','',1477620643,1477620643,5,1),(27,'upload_image_thumb','缩略图尺寸','upload','text','','','不填写则不生成缩略图，如需生成 <code>300x300</code> 的缩略图，则填写 <code>300,300</code> ，请注意，逗号必须是英文逗号','','','','','',2,'','','','',1477644150,1477649513,100,1),(28,'upload_image_thumb_type','缩略图裁剪类型','upload','radio','1','1:等比例缩放\r\n2:缩放后填充\r\n3:居中裁剪\r\n4:左上角裁剪\r\n5:右下角裁剪\r\n6:固定尺寸缩放','该项配置只有在启用生成缩略图时才生效','','','','','',2,'','','','',1477646271,1477649521,100,1),(29,'upload_thumb_water','添加水印','upload','switch','0','','','','','','','',2,'','','','',1477649648,1477649648,100,1),(30,'upload_thumb_water_pic','水印图片','upload','image','','','只有开启水印功能才生效','','','','','',2,'','','','',1477656390,1477656390,100,1),(31,'upload_thumb_water_position','水印位置','upload','radio','9','1:左上角\r\n2:上居中\r\n3:右上角\r\n4:左居中\r\n5:居中\r\n6:右居中\r\n7:左下角\r\n8:下居中\r\n9:右下角','只有开启水印功能才生效','','','','','',2,'','','','',1477656528,1477656528,100,1),(32,'upload_thumb_water_alpha','水印透明度','upload','text','50','','请输入0~100之间的数字，数字越小，透明度越高','','','','','',2,'','','','',1477656714,1477661309,100,1),(33,'wipe_cache_type','清除缓存类型','system','checkbox','TEMP_PATH','TEMP_PATH:应用缓存\r\nLOG_PATH:应用日志\r\nCACHE_PATH:项目模板缓存','清除缓存时，要删除的缓存类型','','','','','',2,'','','','',1477727305,1477727305,100,1),(34,'captcha_signin','后台验证码开关','system','switch','0','','后台登录时是否需要验证码','','','','','',2,'','','','',1478771958,1478771958,99,1),(35,'home_default_module','前台默认模块','system','select','index','','前台默认访问的模块，该模块必须有Index控制器和index方法','','','','','',0,'','','','',1486714723,1486715620,104,1),(36,'minify_status','开启minify','system','switch','0','','开启minify会压缩合并js、css文件，可以减少资源请求次数，如果不支持minify，可关闭','','','','','',0,'','','','',1487035843,1487035843,99,1),(37,'upload_driver','上传驱动','upload','radio','local','local:本地','图片或文件上传驱动','','','','','',0,'','','','',1501488567,1501490821,100,1),(38,'system_log','系统日志','system','switch','1','','是否开启系统日志功能','','','','','',0,'','','','',1512635391,1512635391,99,1),(39,'asset_version','资源版本号','develop','text','20180327','','可通过修改版号强制用户更新静态文件','','','','','',0,'','','','',1522143239,1522143239,100,1);
/*!40000 ALTER TABLE `df_admin_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_admin_hook`
--

DROP TABLE IF EXISTS `df_admin_hook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_admin_hook` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `plugin` varchar(32) NOT NULL DEFAULT '' COMMENT '钩子来自哪个插件',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子描述',
  `system` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统钩子',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='钩子表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_admin_hook`
--

LOCK TABLES `df_admin_hook` WRITE;
/*!40000 ALTER TABLE `df_admin_hook` DISABLE KEYS */;
INSERT INTO `df_admin_hook` VALUES (1,'admin_index','','后台首页',1,1468174214,1477757518,1),(2,'plugin_index_tab_list','','插件扩展tab钩子',1,1468174214,1468174214,1),(3,'module_index_tab_list','','模块扩展tab钩子',1,1468174214,1468174214,1),(4,'page_tips','','每个页面的提示',1,1468174214,1468174214,1),(5,'signin_footer','','登录页面底部钩子',1,1479269315,1479269315,1),(6,'signin_captcha','','登录页面验证码钩子',1,1479269315,1479269315,1),(7,'signin','','登录控制器钩子',1,1479386875,1479386875,1),(8,'upload_attachment','','附件上传钩子',1,1501493808,1501493808,1),(9,'page_plugin_js','','页面插件js钩子',1,1503633591,1503633591,1),(10,'page_plugin_css','','页面插件css钩子',1,1503633591,1503633591,1),(11,'signin_sso','','单点登录钩子',1,1503633591,1503633591,1),(12,'signout_sso','','单点退出钩子',1,1503633591,1503633591,1),(13,'user_add','','添加用户钩子',1,1503633591,1503633591,1),(14,'user_edit','','编辑用户钩子',1,1503633591,1503633591,1),(15,'user_delete','','删除用户钩子',1,1503633591,1503633591,1),(16,'user_enable','','启用用户钩子',1,1503633591,1503633591,1),(17,'user_disable','','禁用用户钩子',1,1503633591,1503633591,1);
/*!40000 ALTER TABLE `df_admin_hook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_admin_hook_plugin`
--

DROP TABLE IF EXISTS `df_admin_hook_plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_admin_hook_plugin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(32) NOT NULL DEFAULT '' COMMENT '钩子id',
  `plugin` varchar(32) NOT NULL DEFAULT '' COMMENT '插件标识',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='钩子-插件对应表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_admin_hook_plugin`
--

LOCK TABLES `df_admin_hook_plugin` WRITE;
/*!40000 ALTER TABLE `df_admin_hook_plugin` DISABLE KEYS */;
INSERT INTO `df_admin_hook_plugin` VALUES (1,'admin_index','SystemInfo',1477757503,1477757503,1,1),(2,'admin_index','DevTeam',1477755780,1477755780,2,1);
/*!40000 ALTER TABLE `df_admin_hook_plugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_admin_icon`
--

DROP TABLE IF EXISTS `df_admin_icon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_admin_icon` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '图标名称',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图标css地址',
  `prefix` varchar(32) NOT NULL DEFAULT '' COMMENT '图标前缀',
  `font_family` varchar(32) NOT NULL DEFAULT '' COMMENT '字体名',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='图标表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_admin_icon`
--

LOCK TABLES `df_admin_icon` WRITE;
/*!40000 ALTER TABLE `df_admin_icon` DISABLE KEYS */;
/*!40000 ALTER TABLE `df_admin_icon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_admin_icon_list`
--

DROP TABLE IF EXISTS `df_admin_icon_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_admin_icon_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `icon_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '所属图标id',
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT '图标标题',
  `class` varchar(255) NOT NULL DEFAULT '' COMMENT '图标类名',
  `code` varchar(128) NOT NULL DEFAULT '' COMMENT '图标关键词',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='详细图标列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_admin_icon_list`
--

LOCK TABLES `df_admin_icon_list` WRITE;
/*!40000 ALTER TABLE `df_admin_icon_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `df_admin_icon_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_admin_log`
--

DROP TABLE IF EXISTS `df_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_admin_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` longtext NOT NULL COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_admin_log`
--

LOCK TABLES `df_admin_log` WRITE;
/*!40000 ALTER TABLE `df_admin_log` DISABLE KEYS */;
INSERT INTO `df_admin_log` VALUES (1,1,1,3415229591,'admin_user',2,'超级管理员 添加了用户：后台管理员',1,1612337140),(2,30,2,3415229591,'admin_menu',237,'后台管理员 添加了节点：所属模块(admin),所属节点ID(0),节点标题(会员管理),节点链接(member/index/index)',1,1612337319),(3,31,2,3415229591,'admin_menu',237,'后台管理员 编辑了节点：节点ID(237)',1,1612337419),(4,31,2,3415229591,'admin_menu',237,'后台管理员 编辑了节点：节点ID(237)',1,1612337438),(5,30,2,3415229591,'admin_menu',238,'后台管理员 添加了节点：所属模块(admin),所属节点ID(237),节点标题(会员列表),节点链接(member/index/index)',1,1612337458),(6,30,2,3415229591,'admin_menu',239,'后台管理员 添加了节点：所属模块(admin),所属节点ID(238),节点标题(新增),节点链接(member/index/add)',1,1612337476),(7,30,2,3415229591,'admin_menu',240,'后台管理员 添加了节点：所属模块(admin),所属节点ID(238),节点标题(编辑),节点链接(member/index/edit)',1,1612337492),(8,30,2,3415229591,'admin_menu',241,'后台管理员 添加了节点：所属模块(admin),所属节点ID(238),节点标题(删除),节点链接()',1,1612337514),(9,31,2,3415229591,'admin_menu',241,'后台管理员 编辑了节点：节点ID(241)',1,1612337527),(10,30,2,3415229591,'admin_menu',242,'后台管理员 添加了节点：所属模块(admin),所属节点ID(238),节点标题(启用),节点链接(member/index/enable)',1,1612337544),(11,30,2,3415229591,'admin_menu',243,'后台管理员 添加了节点：所属模块(admin),所属节点ID(238),节点标题(禁用),节点链接(member/index/disable)',1,1612337560),(12,30,1,3415232709,'admin_menu',244,'超级管理员 添加了节点：所属模块(admin),所属节点ID(1),节点标题(第三方链接管理),节点链接()',1,1614159233),(13,30,1,3415232709,'admin_menu',245,'超级管理员 添加了节点：所属模块(admin),所属节点ID(244),节点标题(链接列表),节点链接(member/third_link/index)',1,1614160121),(14,30,1,3415232709,'admin_menu',246,'超级管理员 添加了节点：所属模块(admin),所属节点ID(245),节点标题(新增),节点链接(member/third_link/add)',1,1614160156),(15,30,1,3415232709,'admin_menu',247,'超级管理员 添加了节点：所属模块(admin),所属节点ID(245),节点标题(编辑),节点链接(member/third_link/edit)',1,1614160184),(16,30,1,3415232709,'admin_menu',248,'超级管理员 添加了节点：所属模块(admin),所属节点ID(245),节点标题(删除),节点链接(member/third_link/delete)',1,1614160238),(17,30,1,3415232709,'admin_menu',249,'超级管理员 添加了节点：所属模块(admin),所属节点ID(245),节点标题(快速编辑),节点链接(member/third_link/quickedit)',1,1614160301),(18,42,1,3415232709,'admin_config',0,'超级管理员 更新了系统设置：分组(base)',1,1614168335),(19,34,1,3415232709,'admin_menu',214,'超级管理员 禁用了节点：节点ID(214),节点标题(消息管理),节点链接()',1,1614172428),(20,30,1,3415235961,'admin_menu',250,'超级管理员 添加了节点：所属模块(admin),所属节点ID(1),节点标题(群组管理),节点链接()',1,1614684711),(21,30,1,3415235961,'admin_menu',251,'超级管理员 添加了节点：所属模块(admin),所属节点ID(250),节点标题(群组列表),节点链接(member/group/index)',1,1614684839),(22,30,1,3415235961,'admin_menu',252,'超级管理员 添加了节点：所属模块(admin),所属节点ID(250),节点标题(聊天记录),节点链接(member/group/message)',1,1614684898),(23,30,1,3415235961,'admin_menu',253,'超级管理员 添加了节点：所属模块(admin),所属节点ID(251),节点标题(删除),节点链接(member/group/delete)',1,1614687166),(24,30,1,3415235961,'admin_menu',254,'超级管理员 添加了节点：所属模块(admin),所属节点ID(252),节点标题(删除),节点链接(member/group/delete_message)',1,1614687260),(25,30,1,3415235961,'admin_menu',255,'超级管理员 添加了节点：所属模块(admin),所属节点ID(251),节点标题(编辑),节点链接(member/group/edit)',1,1614689772),(26,30,1,3415231292,'admin_menu',256,'超级管理员 添加了节点：所属模块(admin),所属节点ID(237),节点标题(聊天记录),节点链接(member/index/message)',1,1615721921),(27,30,1,3415231292,'admin_menu',257,'超级管理员 添加了节点：所属模块(admin),所属节点ID(256),节点标题(删除),节点链接(member/message/delete)',1,1615722142),(28,31,1,3415231292,'admin_menu',256,'超级管理员 编辑了节点：节点ID(256)',1,1615722174),(29,34,1,3415234173,'admin_menu',222,'超级管理员 禁用了节点：节点ID(222),节点标题(消息中心),节点链接(admin/message/index)',1,1615986243),(30,30,1,3415234173,'admin_menu',258,'超级管理员 添加了节点：所属模块(admin),所属节点ID(1),节点标题(公告管理),节点链接()',1,1615986337),(31,30,1,3415234173,'admin_menu',259,'超级管理员 添加了节点：所属模块(admin),所属节点ID(258),节点标题(系统公告),节点链接(member/note/index)',1,1615986364),(32,30,1,3415234173,'admin_menu',260,'超级管理员 添加了节点：所属模块(admin),所属节点ID(259),节点标题(新增),节点链接(member/note/add)',1,1615986517),(33,30,1,3415234173,'admin_menu',261,'超级管理员 添加了节点：所属模块(admin),所属节点ID(259),节点标题(编辑),节点链接(member/index/edit)',1,1615986543),(34,30,1,3415234173,'admin_menu',262,'超级管理员 添加了节点：所属模块(admin),所属节点ID(259),节点标题(删除),节点链接(member/note/delete)',1,1615986577),(35,31,1,3415234173,'admin_menu',261,'超级管理员 编辑了节点：节点ID(261)',1,1615987766),(36,30,1,3415230840,'admin_menu',263,'超级管理员 添加了节点：所属模块(admin),所属节点ID(237),节点标题(会员角色),节点链接(member/role/index)',1,1616044296),(37,30,1,3415230840,'admin_menu',264,'超级管理员 添加了节点：所属模块(admin),所属节点ID(263),节点标题(新增),节点链接(member/role/add)',1,1616044358),(38,30,1,3415230840,'admin_menu',265,'超级管理员 添加了节点：所属模块(admin),所属节点ID(263),节点标题(编辑),节点链接(member/role/edit)',1,1616044390),(39,30,1,3415230840,'admin_menu',266,'超级管理员 添加了节点：所属模块(admin),所属节点ID(263),节点标题(删除),节点链接(member/role/delete)',1,1616044559),(40,34,1,3415230840,'admin_menu',263,'超级管理员 禁用了节点：节点ID(263),节点标题(会员角色),节点链接(member/role/index)',1,1616046380),(41,31,1,3415230840,'admin_menu',237,'超级管理员 编辑了节点：节点ID(237)',1,1616067483),(42,31,1,3415230840,'admin_menu',250,'超级管理员 编辑了节点：节点ID(250)',1,1616067521),(43,31,1,3415230840,'admin_menu',244,'超级管理员 编辑了节点：节点ID(244)',1,1616067966),(44,31,1,3415230840,'admin_menu',258,'超级管理员 编辑了节点：节点ID(258)',1,1616068326),(45,30,1,3415230840,'admin_menu',267,'超级管理员 添加了节点：所属模块(admin),所属节点ID(2),节点标题(参数管理),节点链接()',1,1616072384),(46,30,1,3415230840,'admin_menu',268,'超级管理员 添加了节点：所属模块(admin),所属节点ID(267),节点标题(参数设置),节点链接(member/system_config/index)',1,1616072407),(47,31,1,3415230840,'admin_menu',267,'超级管理员 编辑了节点：节点ID(267)',1,1616073095),(48,31,1,3415230840,'admin_menu',258,'超级管理员 编辑了节点：节点ID(258)',1,1616073157),(49,31,1,3415230840,'admin_menu',267,'超级管理员 编辑了节点：节点ID(267)',1,1616073258);
/*!40000 ALTER TABLE `df_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_admin_menu`
--

DROP TABLE IF EXISTS `df_admin_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_admin_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上级菜单id',
  `module` varchar(16) NOT NULL DEFAULT '' COMMENT '模块名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '菜单标题',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '菜单图标',
  `url_type` varchar(16) NOT NULL DEFAULT '' COMMENT '链接类型（link：外链，module：模块）',
  `url_value` varchar(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `url_target` varchar(16) NOT NULL DEFAULT '_self' COMMENT '链接打开方式：_blank,_self',
  `online_hide` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '网站上线后是否隐藏',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `system_menu` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统菜单，系统菜单不可删除',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `params` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=269 DEFAULT CHARSET=utf8 COMMENT='后台菜单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_admin_menu`
--

LOCK TABLES `df_admin_menu` WRITE;
/*!40000 ALTER TABLE `df_admin_menu` DISABLE KEYS */;
INSERT INTO `df_admin_menu` VALUES (1,0,'admin','首页','fa fa-fw fa-home','module_admin','admin/index/index','_self',0,1467617722,1477710540,1,1,1,''),(2,1,'admin','快捷操作','fa fa-fw fa-folder-open-o','module_admin','','_self',0,1467618170,1616073297,1,1,1,''),(3,2,'admin','清空缓存','fa fa-fw fa-trash-o','module_admin','admin/index/wipecache','_self',0,1467618273,1616073297,3,1,1,''),(4,0,'admin','系统','fa fa-fw fa-gear','module_admin','admin/system/index','_self',0,1467618361,1477710540,2,1,1,''),(5,4,'admin','系统功能','si si-wrench','module_admin','','_self',0,1467618441,1616073297,1,1,1,''),(6,5,'admin','系统设置','fa fa-fw fa-wrench','module_admin','admin/system/index','_self',0,1467618490,1616073297,1,1,1,''),(7,5,'admin','配置管理','fa fa-fw fa-gears','module_admin','admin/config/index','_self',0,1467618618,1616073297,2,1,1,''),(8,7,'admin','新增','','module_admin','admin/config/add','_self',0,1467618648,1616073297,1,1,1,''),(9,7,'admin','编辑','','module_admin','admin/config/edit','_self',0,1467619566,1616073297,2,1,1,''),(10,7,'admin','删除','','module_admin','admin/config/delete','_self',0,1467619583,1616073297,3,1,1,''),(11,7,'admin','启用','','module_admin','admin/config/enable','_self',0,1467619609,1616073297,4,1,1,''),(12,7,'admin','禁用','','module_admin','admin/config/disable','_self',0,1467619637,1616073297,5,1,1,''),(13,5,'admin','节点管理','fa fa-fw fa-bars','module_admin','admin/menu/index','_self',0,1467619882,1616073297,3,1,1,''),(14,13,'admin','新增','','module_admin','admin/menu/add','_self',0,1467619902,1616073297,1,1,1,''),(15,13,'admin','编辑','','module_admin','admin/menu/edit','_self',0,1467620331,1616073297,2,1,1,''),(16,13,'admin','删除','','module_admin','admin/menu/delete','_self',0,1467620363,1616073297,3,1,1,''),(17,13,'admin','启用','','module_admin','admin/menu/enable','_self',0,1467620386,1616073297,4,1,1,''),(18,13,'admin','禁用','','module_admin','admin/menu/disable','_self',0,1467620404,1616073297,5,1,1,''),(19,68,'user','权限管理','fa fa-fw fa-key','module_admin','','_self',0,1467688065,1477710702,1,1,1,''),(20,19,'user','用户管理','fa fa-fw fa-user','module_admin','user/index/index','_self',0,1467688137,1477710702,1,1,1,''),(21,20,'user','新增','','module_admin','user/index/add','_self',0,1467688177,1477710702,1,1,1,''),(22,20,'user','编辑','','module_admin','user/index/edit','_self',0,1467688202,1477710702,2,1,1,''),(23,20,'user','删除','','module_admin','user/index/delete','_self',0,1467688219,1477710702,3,1,1,''),(24,20,'user','启用','','module_admin','user/index/enable','_self',0,1467688238,1477710702,4,1,1,''),(25,20,'user','禁用','','module_admin','user/index/disable','_self',0,1467688256,1477710702,5,1,1,''),(211,64,'admin','日志详情','','module_admin','admin/log/details','_self',0,1480299320,1616073297,1,0,1,''),(32,4,'admin','扩展中心','si si-social-dropbox','module_admin','','_self',0,1467688853,1616073297,2,1,1,''),(33,32,'admin','模块管理','fa fa-fw fa-th-large','module_admin','admin/module/index','_self',0,1467689008,1616073297,1,1,1,''),(34,33,'admin','导入','','module_admin','admin/module/import','_self',0,1467689153,1616073297,1,1,1,''),(35,33,'admin','导出','','module_admin','admin/module/export','_self',0,1467689173,1616073297,2,1,1,''),(36,33,'admin','安装','','module_admin','admin/module/install','_self',0,1467689192,1616073297,3,1,1,''),(37,33,'admin','卸载','','module_admin','admin/module/uninstall','_self',0,1467689241,1616073297,4,1,1,''),(38,33,'admin','启用','','module_admin','admin/module/enable','_self',0,1467689294,1616073297,5,1,1,''),(39,33,'admin','禁用','','module_admin','admin/module/disable','_self',0,1467689312,1616073297,6,1,1,''),(40,33,'admin','更新','','module_admin','admin/module/update','_self',0,1467689341,1616073297,7,1,1,''),(41,32,'admin','插件管理','fa fa-fw fa-puzzle-piece','module_admin','admin/plugin/index','_self',0,1467689527,1616073297,2,1,1,''),(42,41,'admin','导入','','module_admin','admin/plugin/import','_self',0,1467689650,1616073297,1,1,1,''),(43,41,'admin','导出','','module_admin','admin/plugin/export','_self',0,1467689665,1616073297,2,1,1,''),(44,41,'admin','安装','','module_admin','admin/plugin/install','_self',0,1467689680,1616073297,3,1,1,''),(45,41,'admin','卸载','','module_admin','admin/plugin/uninstall','_self',0,1467689700,1616073297,4,1,1,''),(46,41,'admin','启用','','module_admin','admin/plugin/enable','_self',0,1467689730,1616073297,5,1,1,''),(47,41,'admin','禁用','','module_admin','admin/plugin/disable','_self',0,1467689747,1616073297,6,1,1,''),(48,41,'admin','设置','','module_admin','admin/plugin/config','_self',0,1467689789,1616073297,7,1,1,''),(49,41,'admin','管理','','module_admin','admin/plugin/manage','_self',0,1467689846,1616073297,8,1,1,''),(50,5,'admin','附件管理','fa fa-fw fa-cloud-upload','module_admin','admin/attachment/index','_self',0,1467690161,1616073297,4,1,1,''),(51,70,'admin','文件上传','','module_admin','admin/attachment/upload','_self',0,1467690240,1616073297,1,1,1,''),(52,50,'admin','下载','','module_admin','admin/attachment/download','_self',0,1467690334,1616073297,1,1,1,''),(53,50,'admin','启用','','module_admin','admin/attachment/enable','_self',0,1467690352,1616073297,2,1,1,''),(54,50,'admin','禁用','','module_admin','admin/attachment/disable','_self',0,1467690369,1616073297,3,1,1,''),(55,50,'admin','删除','','module_admin','admin/attachment/delete','_self',0,1467690396,1616073297,4,1,1,''),(56,41,'admin','删除','','module_admin','admin/plugin/delete','_self',0,1467858065,1616073297,11,1,1,''),(57,41,'admin','编辑','','module_admin','admin/plugin/edit','_self',0,1467858092,1616073297,10,1,1,''),(60,41,'admin','新增','','module_admin','admin/plugin/add','_self',0,1467858421,1616073297,9,1,1,''),(61,41,'admin','执行','','module_admin','admin/plugin/execute','_self',0,1467879016,1616073297,12,1,1,''),(62,13,'admin','保存','','module_admin','admin/menu/save','_self',0,1468073039,1616073297,6,1,1,''),(64,5,'admin','系统日志','fa fa-fw fa-book','module_admin','admin/log/index','_self',0,1476111944,1616073297,5,0,1,''),(65,5,'admin','数据库管理','fa fa-fw fa-database','module_admin','admin/database/index','_self',0,1476111992,1616073297,7,0,1,''),(66,32,'admin','数据包管理','fa fa-fw fa-database','module_admin','admin/packet/index','_self',0,1476112326,1616073297,4,0,1,''),(67,19,'user','角色管理','fa fa-fw fa-users','module_admin','user/role/index','_self',0,1476113025,1477710702,3,0,1,''),(68,0,'user','用户','fa fa-fw fa-user','module_admin','user/index/index','_self',0,1476193348,1477710540,3,0,1,''),(69,32,'admin','钩子管理','fa fa-fw fa-anchor','module_admin','admin/hook/index','_self',0,1476236193,1616073297,3,0,1,''),(70,2,'admin','后台首页','fa fa-fw fa-tachometer','module_admin','admin/index/index','_self',0,1476237472,1616073297,1,0,1,''),(71,67,'user','新增','','module_admin','user/role/add','_self',0,1476256935,1477710702,1,0,1,''),(72,67,'user','编辑','','module_admin','user/role/edit','_self',0,1476256968,1477710702,2,0,1,''),(73,67,'user','删除','','module_admin','user/role/delete','_self',0,1476256993,1477710702,3,0,1,''),(74,67,'user','启用','','module_admin','user/role/enable','_self',0,1476257023,1477710702,4,0,1,''),(75,67,'user','禁用','','module_admin','user/role/disable','_self',0,1476257046,1477710702,5,0,1,''),(76,20,'user','授权','','module_admin','user/index/access','_self',0,1476375187,1477710702,6,0,1,''),(77,69,'admin','新增','','module_admin','admin/hook/add','_self',0,1476668971,1616073297,1,0,1,''),(78,69,'admin','编辑','','module_admin','admin/hook/edit','_self',0,1476669006,1616073297,2,0,1,''),(79,69,'admin','删除','','module_admin','admin/hook/delete','_self',0,1476669375,1616073297,3,0,1,''),(80,69,'admin','启用','','module_admin','admin/hook/enable','_self',0,1476669427,1616073297,4,0,1,''),(81,69,'admin','禁用','','module_admin','admin/hook/disable','_self',0,1476669564,1616073297,5,0,1,''),(183,66,'admin','安装','','module_admin','admin/packet/install','_self',0,1476851362,1616073297,1,0,1,''),(184,66,'admin','卸载','','module_admin','admin/packet/uninstall','_self',0,1476851382,1616073297,2,0,1,''),(185,5,'admin','行为管理','fa fa-fw fa-bug','module_admin','admin/action/index','_self',0,1476882441,1616073297,6,0,1,''),(186,185,'admin','新增','','module_admin','admin/action/add','_self',0,1476884439,1616073297,1,0,1,''),(187,185,'admin','编辑','','module_admin','admin/action/edit','_self',0,1476884464,1616073297,2,0,1,''),(188,185,'admin','启用','','module_admin','admin/action/enable','_self',0,1476884493,1616073297,3,0,1,''),(189,185,'admin','禁用','','module_admin','admin/action/disable','_self',0,1476884534,1616073297,4,0,1,''),(190,185,'admin','删除','','module_admin','admin/action/delete','_self',0,1476884551,1616073297,5,0,1,''),(191,65,'admin','备份数据库','','module_admin','admin/database/export','_self',0,1476972746,1616073297,1,0,1,''),(192,65,'admin','还原数据库','','module_admin','admin/database/import','_self',0,1476972772,1616073297,2,0,1,''),(193,65,'admin','优化表','','module_admin','admin/database/optimize','_self',0,1476972800,1616073297,3,0,1,''),(194,65,'admin','修复表','','module_admin','admin/database/repair','_self',0,1476972825,1616073297,4,0,1,''),(195,65,'admin','删除备份','','module_admin','admin/database/delete','_self',0,1476973457,1616073297,5,0,1,''),(210,41,'admin','快速编辑','','module_admin','admin/plugin/quickedit','_self',0,1477713981,1616073297,13,0,1,''),(209,185,'admin','快速编辑','','module_admin','admin/action/quickedit','_self',0,1477713939,1616073297,6,0,1,''),(208,7,'admin','快速编辑','','module_admin','admin/config/quickedit','_self',0,1477713808,1616073297,6,0,1,''),(207,69,'admin','快速编辑','','module_admin','admin/hook/quickedit','_self',0,1477713770,1616073297,6,0,1,''),(212,2,'admin','个人设置','fa fa-fw fa-user','module_admin','admin/index/profile','_self',0,1489049767,1616073297,2,0,1,''),(213,70,'admin','检查版本更新','','module_admin','admin/index/checkupdate','_self',0,1490588610,1616073297,2,0,1,''),(214,68,'user','消息管理','fa fa-fw fa-comments-o','module_admin','','_self',0,1520492129,1520492129,100,0,0,''),(215,214,'user','消息列表','fa fa-fw fa-th-list','module_admin','user/message/index','_self',0,1520492195,1520492195,100,0,1,''),(216,215,'user','新增','','module_admin','user/message/add','_self',0,1520492195,1520492195,100,0,1,''),(217,215,'user','编辑','','module_admin','user/message/edit','_self',0,1520492195,1520492195,100,0,1,''),(218,215,'user','删除','','module_admin','user/message/delete','_self',0,1520492195,1520492195,100,0,1,''),(219,215,'user','启用','','module_admin','user/message/enable','_self',0,1520492195,1520492195,100,0,1,''),(220,215,'user','禁用','','module_admin','user/message/disable','_self',0,1520492195,1520492195,100,0,1,''),(221,215,'user','快速编辑','','module_admin','user/message/quickedit','_self',0,1520492195,1520492195,100,0,1,''),(222,2,'admin','消息中心','fa fa-fw fa-comments-o','module_admin','admin/message/index','_self',0,1520495992,1616073297,4,0,0,''),(223,222,'admin','删除','','module_admin','admin/message/delete','_self',0,1520495992,1616073297,1,0,1,''),(224,222,'admin','启用','','module_admin','admin/message/enable','_self',0,1520495992,1616073297,2,0,1,''),(225,32,'admin','图标管理','fa fa-fw fa-tint','module_admin','admin/icon/index','_self',0,1520908295,1616073297,5,0,1,''),(226,225,'admin','新增','','module_admin','admin/icon/add','_self',0,1520908295,1616073297,1,0,1,''),(227,225,'admin','编辑','','module_admin','admin/icon/edit','_self',0,1520908295,1616073297,2,0,1,''),(228,225,'admin','删除','','module_admin','admin/icon/delete','_self',0,1520908295,1616073297,3,0,1,''),(229,225,'admin','启用','','module_admin','admin/icon/enable','_self',0,1520908295,1616073297,4,0,1,''),(230,225,'admin','禁用','','module_admin','admin/icon/disable','_self',0,1520908295,1616073297,5,0,1,''),(231,225,'admin','快速编辑','','module_admin','admin/icon/quickedit','_self',0,1520908295,1616073297,6,0,1,''),(232,225,'admin','图标列表','','module_admin','admin/icon/items','_self',0,1520923368,1616073297,7,0,1,''),(233,225,'admin','更新图标','','module_admin','admin/icon/reload','_self',0,1520931908,1616073297,8,0,1,''),(234,20,'user','快速编辑','','module_admin','user/index/quickedit','_self',0,1526028258,1526028258,100,0,1,''),(235,67,'user','快速编辑','','module_admin','user/role/quickedit','_self',0,1526028282,1526028282,100,0,1,''),(236,6,'admin','快速编辑','','module_admin','admin/system/quickedit','_self',0,1559054310,1616073297,1,0,1,''),(237,1,'admin','会员管理','fa fa-fw fa-user-o','module_admin','','_self',0,1612337319,1616073297,3,0,1,''),(238,237,'admin','会员列表','','module_admin','member/index/index','_self',0,1612337458,1616073297,1,0,1,''),(239,238,'admin','新增','','module_admin','member/index/add','_self',0,1612337476,1616073297,1,0,1,''),(240,238,'admin','编辑','','module_admin','member/index/edit','_self',0,1612337492,1616073297,2,0,1,''),(241,238,'admin','删除','','module_admin','member/index/delete','_self',0,1612337514,1616073297,3,0,1,''),(242,238,'admin','启用','','module_admin','member/index/enable','_self',0,1612337544,1616073297,4,0,1,''),(243,238,'admin','禁用','','module_admin','member/index/disable','_self',0,1612337560,1616073297,5,0,1,''),(244,1,'admin','第三方链接管理','fa fa-fw fa-link','module_admin','','_self',0,1614159233,1616073297,5,0,1,''),(245,244,'admin','链接列表','','module_admin','member/third_link/index','_self',0,1614160121,1616073297,1,0,1,''),(246,245,'admin','新增','','module_admin','member/third_link/add','_self',0,1614160156,1616073297,1,0,1,''),(247,245,'admin','编辑','','module_admin','member/third_link/edit','_self',0,1614160184,1616073297,2,0,1,''),(248,245,'admin','删除','','module_admin','member/third_link/delete','_self',0,1614160238,1616073297,3,0,1,''),(249,245,'admin','快速编辑','','module_admin','member/third_link/quickedit','_self',0,1614160302,1616073297,4,0,1,''),(250,1,'admin','群组管理','fa fa-fw fa-group','module_admin','','_self',0,1614684711,1616073297,4,0,1,''),(251,250,'admin','群组列表','','module_admin','member/group/index','_self',0,1614684839,1616073297,1,0,1,''),(252,250,'admin','聊天记录','','module_admin','member/group/message','_self',0,1614684898,1616073297,2,0,1,''),(253,251,'admin','删除','','module_admin','member/group/delete','_self',0,1614687166,1616073297,1,0,1,''),(254,252,'admin','删除','','module_admin','member/group/delete_message','_self',0,1614687260,1616073297,1,0,1,''),(255,251,'admin','编辑','','module_admin','member/group/edit','_self',0,1614689772,1616073297,2,0,1,''),(256,237,'admin','聊天记录','','module_admin','member/message/index','_self',0,1615721921,1616073297,2,0,1,''),(257,256,'admin','删除','','module_admin','member/message/delete','_self',0,1615722142,1616073297,1,0,1,''),(258,1,'admin','公告管理','fa fa-fw fa-bullhorn','module_admin','','_self',0,1615986337,1616073297,6,0,1,''),(259,258,'admin','系统公告','','module_admin','member/note/index','_self',0,1615986364,1616073297,1,0,1,''),(260,259,'admin','新增','','module_admin','member/note/add','_self',0,1615986517,1616073297,1,0,1,''),(261,259,'admin','编辑','','module_admin','member/note/edit','_self',0,1615986543,1616073297,2,0,1,''),(262,259,'admin','删除','','module_admin','member/note/delete','_self',0,1615986577,1616073297,3,0,1,''),(263,237,'admin','会员角色','','module_admin','member/role/index','_self',0,1616044296,1616073297,3,0,0,''),(264,263,'admin','新增','','module_admin','member/role/add','_self',0,1616044358,1616073297,1,0,1,''),(265,263,'admin','编辑','','module_admin','member/role/edit','_self',0,1616044390,1616073297,2,0,1,''),(266,263,'admin','删除','','module_admin','member/role/delete','_self',0,1616044559,1616073297,3,0,1,''),(267,1,'admin','参数管理','fa fa-fw fa-cogs','module_admin','','_self',0,1616072384,1616073297,2,0,1,''),(268,267,'admin','参数设置','','module_admin','member/system_config/index','_self',0,1616072407,1616073297,1,0,1,'');
/*!40000 ALTER TABLE `df_admin_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_admin_message`
--

DROP TABLE IF EXISTS `df_admin_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_admin_message` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid_receive` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '接收消息的用户id',
  `uid_send` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发送消息的用户id',
  `type` varchar(128) NOT NULL DEFAULT '' COMMENT '消息分类',
  `content` text NOT NULL COMMENT '消息内容',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `read_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '阅读时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='消息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_admin_message`
--

LOCK TABLES `df_admin_message` WRITE;
/*!40000 ALTER TABLE `df_admin_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `df_admin_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_admin_module`
--

DROP TABLE IF EXISTS `df_admin_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_admin_module` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '模块名称（标识）',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '模块标题',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '图标',
  `description` text NOT NULL COMMENT '描述',
  `author` varchar(32) NOT NULL DEFAULT '' COMMENT '作者',
  `author_url` varchar(255) NOT NULL DEFAULT '' COMMENT '作者主页',
  `config` text COMMENT '配置信息',
  `access` text COMMENT '授权配置',
  `version` varchar(16) NOT NULL DEFAULT '' COMMENT '版本号',
  `identifier` varchar(64) NOT NULL DEFAULT '' COMMENT '模块唯一标识符',
  `system_module` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统模块',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='模块表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_admin_module`
--

LOCK TABLES `df_admin_module` WRITE;
/*!40000 ALTER TABLE `df_admin_module` DISABLE KEYS */;
INSERT INTO `df_admin_module` VALUES (1,'admin','系统','fa fa-fw fa-gear','系统模块，DolphinPHP的核心模块','DolphinPHP','http://www.dolphinphp.com','','','1.0.0','admin.dolphinphp.module',1,1468204902,1468204902,100,1),(2,'user','用户','fa fa-fw fa-user','用户模块，DolphinPHP自带模块','DolphinPHP','http://www.dolphinphp.com','','','1.0.0','user.dolphinphp.module',1,1468204902,1468204902,100,1);
/*!40000 ALTER TABLE `df_admin_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_admin_packet`
--

DROP TABLE IF EXISTS `df_admin_packet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_admin_packet` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '数据包名',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '数据包标题',
  `author` varchar(32) NOT NULL DEFAULT '' COMMENT '作者',
  `author_url` varchar(255) NOT NULL DEFAULT '' COMMENT '作者url',
  `version` varchar(16) NOT NULL,
  `tables` text NOT NULL COMMENT '数据表名',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='数据包表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_admin_packet`
--

LOCK TABLES `df_admin_packet` WRITE;
/*!40000 ALTER TABLE `df_admin_packet` DISABLE KEYS */;
/*!40000 ALTER TABLE `df_admin_packet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_admin_plugin`
--

DROP TABLE IF EXISTS `df_admin_plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_admin_plugin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '插件名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '插件标题',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '图标',
  `description` text NOT NULL COMMENT '插件描述',
  `author` varchar(32) NOT NULL DEFAULT '' COMMENT '作者',
  `author_url` varchar(255) NOT NULL DEFAULT '' COMMENT '作者主页',
  `config` text NOT NULL COMMENT '配置信息',
  `version` varchar(16) NOT NULL DEFAULT '' COMMENT '版本号',
  `identifier` varchar(64) NOT NULL DEFAULT '' COMMENT '插件唯一标识符',
  `admin` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台管理',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='插件表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_admin_plugin`
--

LOCK TABLES `df_admin_plugin` WRITE;
/*!40000 ALTER TABLE `df_admin_plugin` DISABLE KEYS */;
INSERT INTO `df_admin_plugin` VALUES (1,'SystemInfo','系统环境信息','fa fa-fw fa-info-circle','在后台首页显示服务器信息','蔡伟明','http://www.caiweiming.com','{\"__token__\":\"707b9825a316e2176453600b38fac2a7\",\"display\":\"1\",\"width\":\"6\"}','1.0.0','system_info.ming.plugin',0,1477757503,1477757503,100,1),(2,'DevTeam','开发团队成员信息','fa fa-fw fa-users','开发团队成员信息','蔡伟明','http://www.caiweiming.com','{\"__token__\":\"6c131924fc790708f956a6b625156f8e\",\"display\":\"0\",\"width\":\"6\"}','1.0.0','dev_team.ming.plugin',0,1477755780,1477755780,100,1);
/*!40000 ALTER TABLE `df_admin_plugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_admin_role`
--

DROP TABLE IF EXISTS `df_admin_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_admin_role` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '角色id',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上级角色',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '角色名称',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '角色描述',
  `menu_auth` text NOT NULL COMMENT '菜单权限',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `access` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否可登录后台',
  `default_module` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '默认访问模块',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='角色表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_admin_role`
--

LOCK TABLES `df_admin_role` WRITE;
/*!40000 ALTER TABLE `df_admin_role` DISABLE KEYS */;
INSERT INTO `df_admin_role` VALUES (1,0,'超级管理员','系统默认创建的角色，拥有最高权限','',0,1476270000,1468117612,1,1,0);
/*!40000 ALTER TABLE `df_admin_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_admin_user`
--

DROP TABLE IF EXISTS `df_admin_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_admin_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL DEFAULT '' COMMENT '用户名',
  `nickname` varchar(32) NOT NULL DEFAULT '' COMMENT '昵称',
  `password` varchar(96) NOT NULL DEFAULT '' COMMENT '密码',
  `email` varchar(64) NOT NULL DEFAULT '' COMMENT '邮箱地址',
  `email_bind` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否绑定邮箱地址',
  `mobile` varchar(11) NOT NULL DEFAULT '' COMMENT '手机号码',
  `mobile_bind` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否绑定手机号码',
  `avatar` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '头像',
  `money` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '余额',
  `score` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '积分',
  `role` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '角色ID',
  `group` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '部门id',
  `signup_ip` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '注册ip',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `last_login_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '最后一次登录时间',
  `last_login_ip` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '登录ip',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态：0禁用，1启用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_admin_user`
--

LOCK TABLES `df_admin_user` WRITE;
/*!40000 ALTER TABLE `df_admin_user` DISABLE KEYS */;
INSERT INTO `df_admin_user` VALUES (1,'admin','超级管理员','$2y$10$2CioOaAT7P/xAyCWQoa4K.jgqbY8U9lTQ49viOTvA5W/O.vwYcW3K','',0,'',0,0,0.00,0,1,0,0,1476065410,1616261151,1616261150,1964274151,100,1),(2,'root','后台管理员','$2y$10$opH4W8PooO58TdAkZqVhKeSES0tzRQ9BCYOb4LhubzgNPZgRNtKsW','',0,'',0,0,0.00,0,1,0,0,1612337141,1612337181,1612337181,3415229591,100,1);
/*!40000 ALTER TABLE `df_admin_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_apply`
--

DROP TABLE IF EXISTS `df_apply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_apply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `send_mid` int(10) unsigned NOT NULL DEFAULT '0',
  `to_mid` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1-好友申请|2-加入群申请',
  `icon` char(50) NOT NULL DEFAULT '/static/image/noteico.png',
  `content` text CHARACTER SET utf8mb4 NOT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '0-申请中|1-已通过|2-拒绝',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_apply`
--

LOCK TABLES `df_apply` WRITE;
/*!40000 ALTER TABLE `df_apply` DISABLE KEYS */;
INSERT INTO `df_apply` VALUES (1,2,1,1,'/static/image/noteico.png','我是10086',1,1614505974,1614505981),(2,2,3,1,'/static/image/noteico.png','我是10086',1,1614510470,1614510475),(3,3,1,1,'/static/image/noteico.png','我是ATM666',1,1614517346,1614517351),(4,2,1,1,'/static/image/noteico.png','我是10086',1,1614672189,1614672198),(7,4,1,1,'/static/image/noteico.png','我是group1',0,1614747844,1614747844),(8,6,2,1,'/static/image/noteico.png','我是testhead2',1,1615649565,1615649650),(9,6,3,1,'/static/image/noteico.png','我是testhead2',1,1615649946,1615649985),(10,13,14,1,'/static/image/noteico.png','我是ceshi008',1,1616166831,1616166837),(13,2,7,2,'/static/image/noteico.png','用户名为:10086 的用户申请入群',1,1616246046,1616246061),(16,2,7,2,'/static/image/noteico.png','用户名为:10086 的用户申请入群',1,1616246979,1616247017),(17,11,7,2,'/static/image/noteico.png','用户名为:ATM333 的用户申请入群',1,1616251512,1616251517),(18,23,7,2,'/static/image/noteico.png','用户名为:ATM5555 的用户申请入群',1,1616256845,1616256853),(19,7,16,1,'/static/image/noteico.png','我是kefu01',1,1616257101,1616257106),(20,24,7,2,'/static/image/noteico.png','用户名为:kefu03 的用户申请入群',1,1616257699,1616257706),(21,13,7,2,'/static/image/noteico.png','用户名为:ceshi008 的用户申请入群',0,1616259836,1616259836);
/*!40000 ALTER TABLE `df_apply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_friends`
--

DROP TABLE IF EXISTS `df_friends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_friends` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mid` int(10) unsigned NOT NULL DEFAULT '0',
  `friend_mid` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `me_friend` (`mid`,`friend_mid`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_friends`
--

LOCK TABLES `df_friends` WRITE;
/*!40000 ALTER TABLE `df_friends` DISABLE KEYS */;
INSERT INTO `df_friends` VALUES (3,2,3,1,1614510475,1614510475),(4,3,2,1,1614510475,1614510475),(5,3,1,1,1614517351,1614517351),(6,1,3,1,1614517351,1614517351),(7,2,1,1,1614672198,1614672198),(8,1,2,1,1614672198,1614672198),(9,6,2,1,1615649650,1615649650),(10,2,6,1,1615649650,1615649650),(11,6,3,1,1615649985,1615649985),(12,3,6,1,1615649985,1615649985),(13,8,7,1,1616139566,1616139566),(14,7,8,1,1616139566,1616139566),(15,10,7,1,1616141130,1616141130),(16,7,10,1,1616141130,1616141130),(17,10,9,1,1616141130,1616141130),(18,9,10,1,1616141130,1616141130),(19,11,7,1,1616143154,1616143154),(20,7,11,1,1616143154,1616143154),(21,11,9,1,1616143154,1616143154),(22,9,11,1,1616143154,1616143154),(23,12,7,1,1616143262,1616143262),(24,7,12,1,1616143262,1616143262),(25,12,9,1,1616143262,1616143262),(26,9,12,1,1616143262,1616143262),(27,13,7,1,1616166620,1616166620),(28,7,13,1,1616166620,1616166620),(29,13,9,1,1616166620,1616166620),(30,9,13,1,1616166620,1616166620),(31,14,7,1,1616166777,1616166777),(32,7,14,1,1616166777,1616166777),(33,14,9,1,1616166777,1616166777),(34,9,14,1,1616166777,1616166777),(35,13,14,1,1616166837,1616166837),(36,14,13,1,1616166837,1616166837),(37,15,7,1,1616251841,1616251841),(38,7,15,1,1616251841,1616251841),(39,15,9,1,1616251841,1616251841),(40,9,15,1,1616251841,1616251841),(41,17,7,1,1616252190,1616252190),(42,7,17,1,1616252190,1616252190),(43,17,9,1,1616252190,1616252190),(44,9,17,1,1616252190,1616252190),(45,17,16,1,1616252190,1616252190),(46,16,17,1,1616252190,1616252190),(47,18,7,1,1616252348,1616252348),(48,7,18,1,1616252348,1616252348),(49,18,9,1,1616252348,1616252348),(50,9,18,1,1616252348,1616252348),(51,18,16,1,1616252348,1616252348),(52,16,18,1,1616252348,1616252348),(53,19,7,1,1616255199,1616255199),(54,7,19,1,1616255199,1616255199),(55,19,9,1,1616255199,1616255199),(56,9,19,1,1616255199,1616255199),(57,19,16,1,1616255199,1616255199),(58,16,19,1,1616255199,1616255199),(59,20,7,1,1616255438,1616255438),(60,7,20,1,1616255438,1616255438),(61,20,9,1,1616255438,1616255438),(62,9,20,1,1616255438,1616255438),(63,20,16,1,1616255438,1616255438),(64,16,20,1,1616255438,1616255438),(65,21,7,1,1616255993,1616255993),(66,7,21,1,1616255993,1616255993),(67,21,9,1,1616255993,1616255993),(68,9,21,1,1616255993,1616255993),(69,21,16,1,1616255993,1616255993),(70,16,21,1,1616255993,1616255993),(71,22,7,1,1616256125,1616256125),(72,7,22,1,1616256125,1616256125),(73,22,9,1,1616256125,1616256125),(74,9,22,1,1616256125,1616256125),(75,22,16,1,1616256125,1616256125),(76,16,22,1,1616256125,1616256125),(77,23,7,1,1616256829,1616256829),(78,7,23,1,1616256829,1616256829),(79,23,9,1,1616256829,1616256829),(80,9,23,1,1616256829,1616256829),(81,23,16,1,1616256829,1616256829),(82,16,23,1,1616256829,1616256829),(83,7,16,1,1616257106,1616257106),(84,16,7,1,1616257106,1616257106),(85,25,7,1,1616260875,1616260875),(86,7,25,1,1616260875,1616260875),(87,25,9,1,1616260875,1616260875),(88,9,25,1,1616260875,1616260875),(89,25,16,1,1616260875,1616260875),(90,16,25,1,1616260875,1616260875),(91,25,24,1,1616260875,1616260875),(92,24,25,1,1616260875,1616260875);
/*!40000 ALTER TABLE `df_friends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_group`
--

DROP TABLE IF EXISTS `df_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL DEFAULT '' COMMENT '群名称',
  `manage` text NOT NULL COMMENT '群管理员[如:1,2,3...]',
  `members` text NOT NULL COMMENT '群成员[如:1,2,3...]',
  `icon` char(100) NOT NULL DEFAULT '/static/image/group.png' COMMENT '群图标',
  `description` text CHARACTER SET utf8mb4 NOT NULL COMMENT '无',
  `notice` text CHARACTER SET utf8mb4 NOT NULL COMMENT '群公告',
  `created_mid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建者ID-群主',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '群状态',
  `is_recommend` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '是否推荐',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_group`
--

LOCK TABLES `df_group` WRITE;
/*!40000 ALTER TABLE `df_group` DISABLE KEYS */;
INSERT INTO `df_group` VALUES (2,'群二','2,1','2,1,3','http://156.245.19.199/static/home/img/group.png','暂无','',2,1,0,1614509796,1614770785),(3,'群三','2','2','http://156.245.19.199/static/home/img/group.png','暂无','',2,1,0,1614516902,1614516902),(4,'群5','3','3','http://156.245.19.199/static/home/img/group.png','暂无','',3,1,0,1614517449,1614517449),(5,'VIP群','24,16,7','7,14,2,11,23,16,24','http://156.245.19.199/static/home/img/group.png','学习、交流，购物，游戏','',7,1,1,1616171313,1616257871),(9,'VIP高级群','7','7,16','http://156.245.19.199/static/home/img/group.png','暂无','',7,1,0,1616171729,1616171729),(10,'test1','2','2','http://156.245.19.199/static/home/img/group.png','暂无','',2,1,0,1616172773,1616172773),(11,'test2','2','2','/static/image/group.png','暂无','',2,1,0,1616173005,1616173005);
/*!40000 ALTER TABLE `df_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_member`
--

DROP TABLE IF EXISTS `df_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `status` tinyint(5) NOT NULL DEFAULT '1',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  `last_login_time` int(11) NOT NULL DEFAULT '0',
  `last_login_ip` char(100) NOT NULL DEFAULT '0.0.0.0',
  `location` char(100) NOT NULL DEFAULT '',
  `role` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '会员角色',
  `is_jianguan` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否是维权监管',
  `is_kefu` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否是客服',
  `balance` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `freeze_balance` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '冻结余额',
  `usdt_address` varchar(100) NOT NULL DEFAULT '',
  `nickname` char(20) NOT NULL DEFAULT '',
  `signature` varchar(100) NOT NULL DEFAULT '' COMMENT '个性签名',
  `groups` char(100) NOT NULL DEFAULT '' COMMENT '群ID[如:1,2,3...]',
  `avatar` varchar(100) NOT NULL DEFAULT '' COMMENT '头像',
  `phone_number` char(20) NOT NULL DEFAULT '' COMMENT '手机号码',
  `usdt_account` char(20) NOT NULL DEFAULT '' COMMENT 'usdt开户人',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COMMENT='会员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_member`
--

LOCK TABLES `df_member` WRITE;
/*!40000 ALTER TABLE `df_member` DISABLE KEYS */;
INSERT INTO `df_member` VALUES (1,'95599','$2y$10$1JwKeZzt8CL6J1wEIut3ceYOcCscHj57D0HmqKsf0PTrDk7LBgvwS',1,1614505941,1616049626,1616049626,'3415230840','',1,0,0,0.00,0.00,'','','','2','/static/image/boy.jpg','',''),(2,'10086','$2y$10$liXbkvxn.vZwx5jOdVWC2u1ZqNedItmqMkXu0LpFqRqGNHeNEgW7O',1,1614505964,1616248770,1616248769,'3415230840','',1,0,0,0.00,0.00,'','','','2,3,10,11,5','/static/image/boy.jpg','',''),(3,'ATM666','$2y$10$IQUrozNgpA7mRA27MWpN4OqU8zN1MxtO4DX/2o7QgFJmbRNtdXhN.',1,1614510452,1616249256,1616249256,'3415230840','',1,0,0,0.00,0.00,'','','','4,2','/static/image/boy.jpg','',''),(4,'group1','$2y$10$OOX.XcwvnXEXsEXWCQNv/ORiCpYNCEWk/f7AVyzVOtqt0IaWQ1RUa',1,1614745262,1614747730,1614747729,'3415235961','',1,0,0,0.00,0.00,'','','','','/static/image/boy.jpg','',''),(5,'testhead1','$2y$10$tT1aX6B.k4aZJRTx7KMpWudosehUhZoVEnyIOfKfg76Atf1wgr.x.',1,1615648995,1616049612,1616049612,'3415230840','',1,0,0,0.00,0.00,'','','','','/static/img/im/face/face_11.jpg','',''),(6,'testhead2','$2y$10$sPIeLbNq/5BJdBjeip1qDOPvwcC10XrsSIB6ZEozyF430isQatwnC',1,1615649083,1616049571,1616049570,'3415230840','',1,0,0,0.00,0.00,'','','','','/static/img/im/face/face_2.jpg','',''),(7,'kefu01','$2y$10$uX8511w7yji6oXNIYOv0YO2UVPE7T7yK0uteedw2Hez1/wSRj.eNy',1,1616050798,1616256181,1616256181,'3415230840','',1,0,1,0.00,0.00,'','','','5,9','/static/logo.png','',''),(8,'ATM111','$2y$10$A2eptes75VLhJIzYO3d3JuCjGAEYRFTndDIxegRXDhDWJ.ubjZ6g2',1,1616139566,1616139566,1616139565,'3415230840','',1,0,0,0.00,0.00,'','','','','/static/img/im/face/face_2.jpg','',''),(9,'weiquanjianguan','$2y$10$hDjnqVqd6I2pRM9MeG/xp.j.jc1dL.prr1dU7X0ujAWPAHLcZpm16',1,1616141097,1616156898,0,'0.0.0.0','',1,1,1,0.00,0.00,'','第三方维权监管','','','http://156.245.19.199/uploads/images/weiquan.jpg','',''),(10,'ATM222','$2y$10$IAXWg6vMa6EQ8a4tkMnIq.fhD8dO87XCjuIhyMU.92GqB2k6s.Wa.',1,1616141130,1616142903,1616142902,'3415230840','',1,0,0,0.00,0.00,'','','','','/static/img/im/face/face_5.jpg','',''),(11,'ATM333','$2y$10$Ndm493rm9HBBvsOSCJRHGO8OEIzShH.8a2H15QihHa0a4QL3VQR5a',1,1616143154,1616259915,1616259915,'3415230840','',1,0,0,0.00,0.00,'','','','5','/static/img/im/face/face_13.jpg','',''),(12,'ATM444','$2y$10$bSvBYhcaecHQjRKucrHcJezTE7fS8Qxr.8ccOELSHywEtPdmHi0rG',1,1616143262,1616221557,1616221557,'3415230840','',1,0,0,0.00,0.00,'','','','','/static/img/im/face/face_15.jpg','',''),(13,'ceshi008','$2y$10$mkkwp3agAnbssqjky3zI5esrmPsVwLmno8J93tQggMeoOe24PtXhC',1,1616166620,1616259559,1616259559,'1964274151','',1,0,0,0.00,0.00,'','','','','/static/image/guanxi.jpg','',''),(14,'ceshi009','$2y$10$ry737Ukd0ViMOsORGKdfEOR2ZQaStflkFb9zebRPSnf7Gt.d3m/V.',1,1616166777,1616166777,1616166777,'3415236054','',1,0,0,0.00,0.00,'','','','5','/static/img/im/face/face_14.jpg','',''),(15,'ATM555','$2y$10$MbyjSOO3XelC6D1EALfuQ.Juj0f/je1iBLt7iZMePuO0tCSgqsKxi',1,1616251841,1616251841,1616251841,'3415230840','',1,0,0,0.00,0.00,'','','','','/static/image/huge.jpg','',''),(16,'kefu02','$2y$10$DG3ix3tY7Su0J3DqK5aRHujxH/6ftQtBtf1ljMJ/aA/qBChEUr5L2',1,1616251941,1616256763,1616256763,'1783336290','',1,0,1,0.00,0.00,'','客服02','','5,9','/static/logo.png','',''),(17,'ATM777','$2y$10$EtgQfvO1XsKgfUNzTg4Xheu8PMta2vGebMCVlHJmHchorQO1ZRFCG',1,1616252190,1616252190,1616252190,'3415230840','',1,0,0,0.00,0.00,'','','','','/static/img/im/face/face_11.jpg','',''),(18,'ATM888','$2y$10$JJjc5xUQBOZzUOA.BSQ.r.lyNX0J7q1jtoy9v2/rPJ3tAR0hKEl/m',1,1616252348,1616252348,1616252348,'3415230840','',1,0,0,0.00,0.00,'','','','','/static/img/im/face/face_9.jpg','',''),(19,'ATM1111','$2y$10$KsaakUOPKiaKf4XcRTbANuTD9bsNuIub1Iq41YrWUzGfbBPAdNoAS',1,1616255199,1616255199,1616255199,'3415230840','',1,0,0,0.00,0.00,'','','','','/static/img/im/face/face_3.jpg','',''),(20,'ATM2222','$2y$10$KtEBt.AF0W58ZL6gS8NcZu22wWIEzKNzk9SXYUMnw4dGwKAhe3Qha',1,1616255438,1616255438,1616255437,'3415230840','',1,0,0,0.00,0.00,'','','','','/static/img/im/face/face_12.jpg','',''),(21,'ATM3333','$2y$10$0XhoKXVSE/r2kDvKk6UVDOXKnk.d.1LgqMSvfFk7Fiwg0pJAn21K.',1,1616255993,1616255994,1616255993,'3415230840','',1,0,0,0.00,0.00,'','','','','/static/img/im/face/face_2.jpg','',''),(22,'ATM4444','$2y$10$tCQhWU0ojgeElaK8m6c75OTnPnTEgZGO6AVNlGenqrpKEXwPWGfW.',1,1616256125,1616256126,1616256125,'3415230840','',1,0,0,0.00,0.00,'','','','','/static/img/im/face/face_4.jpg','',''),(23,'ATM5555','$2y$10$IttygCloE2TCO/VgN2yDdukwRY/pVb9wgWO28lRUWJqXPNhBrYk1u',1,1616256829,1616256830,1616256829,'3415230840','',1,0,0,0.00,0.00,'','','','5','/static/img/im/face/face_14.jpg','',''),(24,'kefu03','$2y$10$rJkdvZWgpJq00kWXfQ6r.OCQ4uGix0vnU3ZPWCNxcptU2wjNztVBy',1,1616257394,1616257650,1616257650,'3415230840','',1,0,1,0.00,0.00,'','客服03','','5','/static/logo.png','',''),(25,'test2021','$2y$10$PPuCjodKNFzbjILBv5s6COeeoeDLBwXj9.iKwf3iJcLOadydCfVE6',1,1616260875,1616260875,1616260875,'3415231265','',1,0,0,0.00,0.00,'','','','','/static/img/im/face/face_6.jpg','','');
/*!40000 ALTER TABLE `df_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_member_role`
--

DROP TABLE IF EXISTS `df_member_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_member_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(50) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '角色名',
  `flag` char(50) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '角色标识',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_member_role`
--

LOCK TABLES `df_member_role` WRITE;
/*!40000 ALTER TABLE `df_member_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `df_member_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_message`
--

DROP TABLE IF EXISTS `df_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `send_mid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '发送方会员ID',
  `to_mid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '被发送会员ID',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '消息类型:1-文本|2-语音|3-图片|5-视频',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '消息状态:1-未读,2-已收,3-已读',
  `content` text CHARACTER SET utf8mb4 NOT NULL COMMENT '消息内容',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  `send_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '发送时间',
  `receive_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收到时间',
  `read_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '读取时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=236 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_message`
--

LOCK TABLES `df_message` WRITE;
/*!40000 ALTER TABLE `df_message` DISABLE KEYS */;
INSERT INTO `df_message` VALUES (4,3,2,1,3,'我们已经加为好友了，可以开始聊天了！',1614510475,1614519802,1614510475,0,1614519802),(5,3,2,1,3,'🌝🌝',1614510508,1614652983,1614510508,1614510508,1614652983),(6,3,2,1,3,'gsge\nsdd\newd\nsd\ne\nd\nd\nd\nd\nd\nf\nf\ndd\nd',1614510606,1614671704,1614510606,1614510606,1614671704),(7,2,3,1,3,'nice',1614510666,1616079226,1614510666,1614510666,1616079226),(8,2,3,1,3,'Tt\'s ok',1614510679,1616079224,1614510679,1614510679,1616079224),(9,3,2,1,3,'1',1614510696,1614762489,1614510696,1614510696,1614762489),(10,3,2,1,3,'2',1614510705,1614770407,1614510705,1614510706,1614770407),(11,2,3,3,3,'{\"url\":\"http://156.245.19.199/uploads/images/20210228/chkdpgdpnlv.png\",\"w\":300,\"h\":249}',1614512681,1616079224,1614512681,0,1616079224),(17,1,3,1,3,'我们已经加为好友了，可以开始聊天了！',1614517351,1616250869,1614517351,0,1616250869),(18,1,3,1,3,'你好',1614517365,1616250869,1614517365,1614517365,1616250869),(19,3,2,2,3,'{\"length\":\"00:12\",\"url\":\"http://156.245.19.199/uploads/voices/20210228/1614517484826.mp3\"}',1614517500,1614772154,1614517500,1614517500,1614772154),(20,3,2,3,3,'{\"url\":\"http://156.245.19.199/uploads/images/20210228/1614518452159_1614518437554.jpg\",\"w\":2448,\"h\":3264}',1614518455,1614772154,1614518455,1614518456,1614772154),(21,3,2,2,3,'{\"length\":\"00:05\",\"url\":\"http://156.245.19.199/uploads/voices/20210228/1614519917567.mp3\"}',1614519926,1614775154,1614519926,1614519926,1614775154),(24,3,2,5,3,'{\"url\":\"http://156.245.19.199/uploads/videos/20210302/VID-20210131-WA0001.mp4\",\"w\":\"1366\",\"h\":\"768\"}',1614665288,1614775292,1614665288,1614665288,1614775292),(25,1,2,1,3,'我们已经加为好友了，可以开始聊天了！',1614672198,1615626442,1614672198,0,1615626442),(26,2,1,1,3,'ok',1614677954,1614751585,1614677954,0,1614751585),(27,2,1,1,3,'我们是花木成畦手自栽工苦',1614678619,1614751585,1614678619,0,1614751585),(28,2,1,1,3,'问渠哪得清如许，唯有源头活水来',1614678659,1614751585,1614678659,0,1614751585),(29,2,1,1,3,'大风起兮云飞扬，威加海内兮归故乡，安德猛士兮守四方',1614678927,1614751585,1614678927,0,1614751585),(30,3,2,1,3,'🌚🌚🐂🍺',1614680134,1614847219,1614680134,1614680134,1614847219),(32,2,3,1,3,'1',1614759863,1616079224,1614759863,1614759863,1616079224),(33,2,3,1,3,'2',1614762491,1616079223,1614762491,1614762491,1616079223),(34,2,3,1,3,'3',1614762507,1616079223,1614762507,1614762507,1616079223),(35,2,3,1,3,'1',1614770411,1616079223,1614770411,1614770411,1616079223),(36,2,3,1,3,'1',1614772157,1616079223,1614772157,0,1616079223),(37,2,3,1,3,'2',1614772333,1616079223,1614772333,1614772333,1616079223),(38,2,3,1,3,'2',1614772335,1616079223,1614772335,1614772335,1616079223),(39,2,3,1,3,'1',1614775157,1616079223,1614775157,1614775157,1616079223),(40,2,3,1,3,'2',1614775294,1616079223,1614775294,1614775294,1616079223),(41,3,1,1,1,'http://www.google.com',1614826857,1614826857,1614826857,0,0),(42,2,1,1,1,'http://www.google.com',1614828373,1614828373,1614828373,0,0),(43,2,1,1,1,'test<img src=\"https://s2.ax1x.com/2019/04/12/AbNQgA.gif\"><img src=\"https://s2.ax1x.com/2019/04/12/AbNQgA.gif\">',1614832510,1614832510,1614832510,0,0),(44,2,1,1,1,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNQgA.gif\">',1614847122,1614847122,1614847122,0,0),(45,2,3,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNQgA.gif\">',1614847222,1616079223,1614847222,1614847222,1616079223),(46,2,3,1,3,'1',1614847235,1616079223,1614847235,1614847235,1616079223),(47,2,3,3,3,'{\"url\":\"http://156.245.19.199/uploads/images/20210304/chkdpgdpnlv.png\",\"w\":300,\"h\":249}',1614847250,1616079222,1614847250,1614847250,1616079222),(48,2,3,1,3,'aa<img src=\"https://s2.ax1x.com/2019/04/12/AbNQgA.gif\">',1614847318,1616079222,1614847318,1614847318,1616079222),(49,2,3,1,3,'aa\nbb\ncc',1614847779,1616079222,1614847779,0,1616079222),(50,2,3,1,3,'花木成畦手自栽 花木成畦手自栽花木成畦手自栽 ',1614847806,1616079222,1614847806,0,1616079222),(52,2,3,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNQgA.gif\">',1614849514,1616079222,1614849514,1614849514,1616079222),(53,2,3,1,3,'nice',1614851895,1616079222,1614851895,1614851895,1616079222),(54,2,1,1,1,'1',1614851952,1614851952,1614851952,0,0),(55,3,2,1,3,'ok',1614851983,1615010684,1614851983,1614851983,1615010684),(56,2,3,1,3,'yes',1614851994,1616079222,1614851994,1614851995,1616079222),(57,2,3,1,3,'1',1614852019,1616079222,1614852019,1614852020,1616079222),(58,2,3,1,3,'ok',1614852027,1616079222,1614852027,1614852027,1616079222),(59,3,2,1,3,'ok',1614866183,1615569075,1614866183,0,1615569075),(61,2,1,1,1,'2',1614932778,1614932778,1614932778,0,0),(62,2,3,1,3,'nice',1615006934,1616079222,1615006934,1615006934,1616079222),(66,2,3,1,3,'5',1615010693,1616079222,1615010693,0,1616079222),(68,2,3,1,3,'2',1615555048,1616079222,1615555048,0,1616079222),(70,2,3,1,3,'3',1615565868,1616079222,1615565868,1615565868,1616079222),(71,2,3,1,3,'你好，现在',1615568192,1616079222,1615568192,1615568192,1616079222),(72,3,2,1,3,'ok',1615568579,1615619487,1615568579,1615568579,1615619487),(73,3,2,1,3,'nice',1615568792,1615619487,1615568792,1615568792,1615619487),(74,2,3,1,3,'yes',1615569080,1616079222,1615569080,1615569080,1616079222),(75,3,2,1,3,'ok',1615569106,1615621673,1615569106,1615569106,1615621673),(76,3,2,1,3,'how are you',1615612460,1616217236,1615612460,1615612461,1616217236),(77,2,3,1,3,'I\'m fine',1615613416,1616079220,1615613416,0,1616079220),(79,2,3,1,3,'Hi',1615617885,1616079220,1615617885,1615617885,1616079220),(80,2,3,1,3,'hello',1615618541,1616079220,1615618541,1615618541,1616079220),(81,2,3,1,3,'are you online?',1615619273,1616079220,1615619273,1615619316,1616079220),(83,2,3,1,3,'ok',1615619506,1616079220,1615619506,1615619507,1616079220),(84,2,3,1,3,'again',1615620818,1616079220,1615620818,1615620818,1616079220),(85,2,3,1,3,'nice',1615621677,1616079220,1615621677,1615621677,1616079220),(86,3,2,1,3,'yes',1615622457,1616217236,1615622457,1615622457,1616217236),(87,3,2,1,3,'are you online?',1615622485,1616217236,1615622485,1615622486,1616217236),(88,2,3,1,3,'yes',1615623154,1616079219,1615623154,1615623154,1616079219),(89,3,2,1,3,'ok',1615624088,1616217234,1615624088,1615624088,1616217234),(90,2,3,1,3,'are you ok?',1615624564,1616079219,1615624564,1615625027,1616079219),(91,3,2,1,3,'yes',1615625043,1616217234,1615625043,1615625043,1616217234),(92,2,1,1,1,'3',1615628614,1615628614,1615628614,0,0),(93,2,3,1,3,'ping',1615632540,1616079219,1615632540,1615632541,1616079219),(94,3,2,1,3,'pong',1615632557,1616217234,1615632557,1615632558,1616217234),(95,2,3,1,3,'p',1615632746,1616079219,1615632746,1615632746,1616079219),(96,2,3,1,3,'a',1615633457,1616079219,1615633457,0,1616079219),(97,3,2,1,3,'ping',1615647714,1616217234,1615647714,1615647714,1616217234),(98,2,3,1,3,'pong',1615647726,1616079219,1615647726,1615647727,1616079219),(99,3,2,1,3,'nice',1615647741,1616217250,1615647741,1615647741,1616217250),(100,2,3,1,3,'It\'s ok',1615647757,1616249514,1615647757,1615647757,1616249514),(101,2,6,1,3,'我们已经加为好友了，可以开始聊天了！',1615649650,1615649687,1615649650,0,1615649687),(102,2,6,1,3,'你好',1615649682,1615649687,1615649682,1615649682,1615649687),(103,6,2,1,3,'你好',1615649699,1615649699,1615649699,1615649699,1615649699),(104,2,6,1,3,'1',1615649709,1615649709,1615649709,1615649709,1615649709),(105,2,6,1,3,'2',1615649711,1615649711,1615649711,1615649711,1615649711),(106,2,6,1,3,'3',1615649713,1615649714,1615649713,1615649714,1615649714),(107,2,6,1,3,'4',1615649715,1615649716,1615649715,1615649716,1615649716),(108,2,6,1,3,'5',1615649717,1615649810,1615649717,1615649717,1615649810),(109,2,6,1,3,'6',1615649719,1615649810,1615649719,1615649720,1615649810),(110,2,6,1,3,'7',1615649723,1615649810,1615649723,1615649723,1615649810),(111,6,2,1,3,'7',1615649733,1616173076,1615649733,1615649733,1616173076),(112,6,2,1,3,'6',1615649738,1616173076,1615649738,1615649738,1616173076),(113,6,2,1,3,'5',1615649743,1616173076,1615649743,1615649743,1616173076),(114,6,2,1,3,'4',1615649746,1616173076,1615649746,1615649746,1616173076),(115,6,2,1,3,'3',1615649751,1616173076,1615649751,1615649751,1616173076),(116,6,2,1,3,'2',1615649755,1616173076,1615649755,1615649756,1616173076),(117,6,2,1,3,'1',1615649759,1616173076,1615649759,1615649760,1616173076),(118,3,6,1,3,'我们已经加为好友了，可以开始聊天了！',1615649985,1616049150,1615649985,0,1616049150),(119,3,2,1,3,'1',1615733990,1616217250,1615733990,0,1616217250),(120,2,3,1,3,'can',1615734960,1616249514,1615734960,0,1616249514),(121,2,3,1,3,'are you ok?',1615735457,1616249514,1615735457,1615735457,1616249514),(122,2,3,1,3,'nice',1615736379,1616249514,1615736379,0,1616249514),(123,3,6,1,3,'how are you',1615736838,1616049150,1615736838,0,1616049150),(124,3,2,1,3,'aq',1615790381,1616217250,1615790381,0,1616217250),(125,3,2,1,3,'hao',1615812883,1616217250,1615812883,0,1616217250),(126,2,3,1,3,'ok',1615963189,1616249514,1615963189,0,1616249514),(127,2,3,3,3,'{\"url\":\"http://156.245.19.199/uploads/images/20210317/chkdpgdpnlv.png\",\"w\":300,\"h\":249}',1615974978,1616249514,1615974978,0,1616249514),(128,3,1,1,1,'我们已经加为好友了，可以开始聊天了！',1615998688,1615998688,1615998688,0,0),(129,7,8,1,3,'我们已经成为好友了，可以开始聊天了！',1616139566,1616140858,1616139566,0,1616140858),(130,7,10,1,3,'我们已经成为好友了，可以开始聊天了！',1616141130,1616160877,1616141130,0,1616160877),(131,9,10,1,3,'我们已经成为好友了，可以开始聊天了！',1616141130,1616160880,1616141130,0,1616160880),(132,9,10,1,3,'一小时日赚600-800！赶快下载APP赚钱！免费注册?客服马上带您日赚3000-5000元',1616141130,1616160880,1616141130,0,1616160880),(133,7,11,1,3,'我们已经成为好友了，可以开始聊天了！',1616143154,1616260804,1616143154,0,1616260804),(134,9,11,1,3,'一小时日赚600-800！赶快下载APP赚钱！免费注册?客服马上带您日赚3000-5000元',1616143154,1616260785,1616143154,0,1616260785),(135,9,11,1,3,'我们已经成为好友了，可以开始聊天了！',1616143154,1616260785,1616143154,0,1616260785),(136,7,12,1,3,'我们已经成为好友了，可以开始聊天了！',1616143262,1616172085,1616143262,0,1616172085),(137,9,12,1,3,'一小时日赚600-800！赶快下载APP赚钱！免费注册?客服马上带您日赚3000-5000元',1616143262,1616172089,1616143262,0,1616172089),(138,9,12,1,3,'我们已经成为好友了，可以开始聊天了！',1616143262,1616172089,1616143262,0,1616172089),(139,7,13,1,3,'我们已经成为好友了，可以开始聊天了！',1616166620,1616259806,1616166620,0,1616259806),(140,9,13,1,3,'一小时日赚600-800！赶快下载APP赚钱！免费注册?客服马上带您日赚3000-5000元',1616166620,1616166625,1616166620,0,1616166625),(141,9,13,1,3,'我们已经成为好友了，可以开始聊天了！',1616166620,1616166625,1616166620,0,1616166625),(142,7,14,1,3,'我们已经成为好友了，可以开始聊天了！',1616166777,1616166968,1616166777,0,1616166968),(143,9,14,1,3,'一小时日赚600-800！赶快下载APP赚钱！免费注册?客服马上带您日赚3000-5000元',1616166777,1616171581,1616166777,0,1616171581),(144,9,14,1,3,'我们已经成为好友了，可以开始聊天了！',1616166777,1616171581,1616166777,0,1616171581),(145,14,7,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNwgs.gif\">',1616166831,1616241548,1616166831,0,1616241548),(146,14,13,1,1,'我们已经加为好友了，可以开始聊天了！',1616166837,1616166837,1616166837,0,0),(147,14,13,1,1,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNwgs.gif\"><img src=\"https://s2.ax1x.com/2019/04/12/AbNwgs.gif\">',1616166845,1616166845,1616166845,0,0),(148,14,13,1,1,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNwgs.gif\">',1616166887,1616166887,1616166887,0,0),(149,14,7,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNljI.gif\">',1616166972,1616241548,1616166972,0,1616241548),(150,14,7,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNM3d.gif\">',1616166976,1616241548,1616166976,0,1616241548),(151,14,7,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbN8DP.gif\">',1616166981,1616241548,1616166981,0,1616241548),(152,14,7,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNljI.gif\">',1616166985,1616241548,1616166985,0,1616241548),(153,14,7,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNtUS.gif\">',1616166988,1616241548,1616166988,0,1616241548),(154,14,7,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNGHf.gif\">',1616166993,1616241548,1616166993,0,1616241548),(155,14,7,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNYE8.gif\">',1616166997,1616241548,1616166997,0,1616241548),(156,14,7,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNaCQ.gif\">',1616167001,1616241548,1616167001,0,1616241548),(157,14,13,1,1,'<img src=\"https://s2.ax1x.com/2019/04/12/AbN3ut.gif\">',1616167012,1616167012,1616167012,0,0),(158,14,13,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNM3d.gif\">',1616167016,1616169752,1616167016,0,1616169752),(159,14,13,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbN8DP.gif\">',1616167019,1616169752,1616167019,0,1616169752),(160,14,13,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNljI.gif\">',1616167022,1616169752,1616167022,0,1616169752),(161,14,13,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNtUS.gif\">',1616167026,1616169752,1616167026,0,1616169752),(162,14,13,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNGHf.gif\">',1616167030,1616169752,1616167030,0,1616169752),(163,14,13,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNYE8.gif\">',1616167033,1616169752,1616167033,0,1616169752),(164,14,13,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNaCQ.gif\">',1616167037,1616169752,1616167037,0,1616169752),(165,14,13,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNtUS.gif\">',1616167041,1616259943,1616167041,0,1616259943),(166,14,13,3,3,'{\"url\":\"http://156.245.19.199/uploads/images/20210319/IMG-20210319-WA0035.jpg\",\"w\":198,\"h\":198}',1616167142,1616260072,1616167142,0,1616260072),(167,14,13,3,3,'{\"url\":\"http://156.245.19.199/uploads/images/20210319/IMG-20210319-WA0062.jpg\",\"w\":295,\"h\":488}',1616167150,1616260255,1616167150,0,1616260255),(168,13,14,1,3,'在吗\n',1616169760,1616171567,1616169760,0,1616171567),(169,13,14,1,3,'在的呢\n',1616169766,1616171567,1616169766,0,1616171567),(170,13,14,1,3,'在吗  按 Enter键盘 不能发送\n\n\n\n\n\n',1616169785,1616171567,1616169785,0,1616171567),(171,13,14,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbN8DP.gif\">',1616169790,1616171567,1616169790,0,1616171567),(172,13,14,1,3,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNtUS.gif\">',1616169793,1616171567,1616169793,0,1616171567),(173,13,14,3,3,'{\"url\":\"http://156.245.19.199/uploads/images/20210320/logo.png\",\"w\":1024,\"h\":1024}',1616169799,1616171567,1616169799,0,1616171567),(174,13,14,1,3,'已阅读未阅读 在哪里显示\n\n\n\n\n\n\n',1616169817,1616171567,1616169817,0,1616171567),(175,7,15,1,1,'我们已经成为好友了，可以开始聊天了！',1616251841,1616251841,1616251841,0,0),(176,9,15,1,1,'一小时日赚600-800！赶快下载APP赚钱！免费注册?客服马上带您日赚3000-5000元',1616251841,1616251841,1616251841,0,0),(177,9,15,1,1,'我们已经成为好友了，可以开始聊天了！',1616251841,1616251841,1616251841,0,0),(178,7,17,1,1,'我们已经成为好友了，可以开始聊天了！',1616252190,1616252190,1616252190,0,0),(179,9,17,1,1,'一小时日赚600-800！赶快下载APP赚钱！免费注册?客服马上带您日赚3000-5000元',1616252190,1616252190,1616252190,0,0),(180,9,17,1,1,'我们已经成为好友了，可以开始聊天了！',1616252190,1616252190,1616252190,0,0),(181,16,17,1,1,'我们已经成为好友了，可以开始聊天了！',1616252190,1616252190,1616252190,0,0),(182,7,18,1,1,'我们已经成为好友了，可以开始聊天了！',1616252348,1616252348,1616252348,0,0),(183,9,18,1,1,'一小时日赚600-800！赶快下载APP赚钱！免费注册?客服马上带您日赚3000-5000元',1616252348,1616252348,1616252348,0,0),(184,9,18,1,1,'我们已经成为好友了，可以开始聊天了！',1616252348,1616252348,1616252348,0,0),(185,16,18,1,1,'我们已经成为好友了，可以开始聊天了！',1616252348,1616252348,1616252348,0,0),(186,7,19,1,1,'我们已经成为好友了，可以开始聊天了！',1616255199,1616255199,1616255199,0,0),(187,9,19,1,1,'一小时日赚600-800！赶快下载APP赚钱！免费注册?客服马上带您日赚3000-5000元',1616255199,1616255199,1616255199,0,0),(188,9,19,1,1,'我们已经成为好友了，可以开始聊天了！',1616255199,1616255199,1616255199,0,0),(189,16,19,1,1,'我们已经成为好友了，可以开始聊天了！',1616255199,1616255199,1616255199,0,0),(190,7,20,1,1,'我们已经成为好友了，可以开始聊天了！',1616255438,1616255438,1616255438,0,0),(191,9,20,1,1,'一小时日赚600-800！赶快下载APP赚钱！免费注册?客服马上带您日赚3000-5000元',1616255438,1616255438,1616255438,0,0),(192,9,20,1,1,'我们已经成为好友了，可以开始聊天了！',1616255438,1616255438,1616255438,0,0),(193,16,20,1,1,'我们已经成为好友了，可以开始聊天了！',1616255438,1616255438,1616255438,0,0),(194,7,21,1,3,'我们已经成为好友了，可以开始聊天了！',1616255993,1616256026,1616255993,0,1616256026),(195,9,21,1,1,'一小时日赚600-800！赶快下载APP赚钱！免费注册?客服马上带您日赚3000-5000元',1616255993,1616255993,1616255993,0,0),(196,9,21,1,1,'我们已经成为好友了，可以开始聊天了！',1616255993,1616255993,1616255993,0,0),(197,16,21,1,1,'我们已经成为好友了，可以开始聊天了！',1616255993,1616255993,1616255993,0,0),(198,7,22,1,3,'我们已经成为好友了，可以开始聊天了！',1616256125,1616256139,1616256125,0,1616256139),(199,9,22,1,1,'一小时日赚600-800！赶快下载APP赚钱！免费注册?客服马上带您日赚3000-5000元',1616256125,1616256125,1616256125,0,0),(200,9,22,1,1,'我们已经成为好友了，可以开始聊天了！',1616256125,1616256125,1616256125,0,0),(201,16,22,1,1,'我们已经成为好友了，可以开始聊天了！',1616256125,1616256125,1616256125,0,0),(202,7,23,1,3,'我们已经成为好友了，可以开始聊天了！',1616256829,1616258470,1616256829,0,1616258470),(203,9,23,1,3,'一小时日赚600-800！赶快下载APP赚钱！免费注册?客服马上带您日赚3000-5000元',1616256829,1616258570,1616256829,0,1616258570),(204,9,23,1,3,'我们已经成为好友了，可以开始聊天了！',1616256829,1616258570,1616256829,0,1616258570),(205,16,23,1,3,'我们已经成为好友了，可以开始聊天了！',1616256829,1616258575,1616256829,0,1616258575),(206,16,7,1,3,'我们已经加为好友了，可以开始聊天了！',1616257106,1616260942,1616257106,0,1616260942),(207,13,14,3,1,'{\"url\":\"http://156.245.19.199/uploads/images/20210321/erweima.png.png\",\"w\":512,\"h\":512}',1616259964,1616259964,1616259964,0,0),(208,13,14,1,1,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNljI.gif\">',1616260092,1616260092,1616260092,0,0),(209,7,25,1,1,'我们已经成为好友了，可以开始聊天了！',1616260875,1616260875,1616260875,0,0),(210,9,25,1,3,'一小时日赚600-800！赶快下载APP赚钱！免费注册?客服马上带您日赚3000-5000元',1616260875,1616260940,1616260875,0,1616260940),(211,9,25,1,3,'我们已经成为好友了，可以开始聊天了！',1616260875,1616260940,1616260875,0,1616260940),(212,16,25,1,1,'我们已经成为好友了，可以开始聊天了！',1616260875,1616260875,1616260875,0,0),(213,24,25,1,3,'我们已经成为好友了，可以开始聊天了！',1616260875,1616260952,1616260875,0,1616260952),(214,25,24,1,3,'你好\n\nTEST',1616260909,1616261009,1616260909,1616260909,1616261009),(215,25,24,1,3,'测试',1616260937,1616261009,1616260937,1616260937,1616261009),(216,25,24,3,3,'{\"url\":\"http://156.245.19.199/uploads/images/20210321/e11d28d5-7d77-4c30-9ae6-d9ec0f0ff15a.jpg\",\"w\":269,\"h\":257}',1616260960,1616261009,1616260960,1616260960,1616261009),(217,24,25,1,3,'你好',1616260997,1616260997,1616260997,1616260997,1616260997),(218,25,24,1,3,'测试',1616261005,1616261009,1616261005,1616261005,1616261009),(219,25,24,3,3,'{\"url\":\"http://156.245.19.199/uploads/images/20210321/1.jpg\",\"w\":222,\"h\":222}',1616261017,1616261017,1616261017,1616261017,1616261017),(220,24,25,1,3,'已收到',1616261024,1616261024,1616261024,1616261024,1616261024),(221,25,24,1,3,'亲，我们是北京桔桔网络科技有限公司，有正式牌照，合法正规。\n我们营业执照统一社会信用代码：91110105MA00DGL133\n您现在可登陆国家企业信用信息公式系统进行查询真实性\n查询网址：http://www.gsxt.gov.cn/index.html\n法人代表：王伦\n注册资金：300万人民币\n登记机关：北京市工商行政管理局朝阳分局\n成立时间：2017年4月13日\n公司地址：北京市朝阳区霄云路',1616261153,1616261154,1616261153,1616261154,1616261154),(222,25,24,1,3,'你看得到自己输入的字吗?',1616261172,1616261172,1616261172,1616261172,1616261172),(223,24,25,1,3,'看得见啊',1616261182,1616261182,1616261182,1616261182,1616261182),(224,25,24,3,3,'{\"url\":\"http://156.245.19.199/uploads/images/20210321/QQ截图20210321002628.png\",\"w\":1360,\"h\":113}',1616261198,1616261198,1616261198,1616261198,1616261198),(225,25,24,1,3,'我是说输入宽那边',1616261217,1616261218,1616261217,1616261218,1616261218),(226,24,25,1,3,'目前没有PC端页面。请使用H5的方式模拟\n',1616261230,1616261230,1616261230,1616261230,1616261230),(227,24,25,1,3,'用谷歌浏览器，F12',1616261245,1616261245,1616261245,1616261245,1616261245),(228,25,24,1,3,'然后?',1616261266,1616261266,1616261266,1616261266,1616261266),(229,25,24,1,3,'谷歌点F12',1616261276,1616261276,1616261276,1616261276,1616261276),(230,24,25,3,3,'{\"url\":\"http://156.245.19.199/uploads/images/20210321/屏幕截图 2021-03-21 002745.png\",\"w\":783,\"h\":872}',1616261281,1616261281,1616261281,1616261281,1616261281),(231,25,24,1,3,'发送键可以Enter输入直接发话吗?',1616261300,1616261300,1616261300,1616261300,1616261300),(232,25,24,1,3,'不要每次都去点发送',1616261315,1616261315,1616261315,1616261315,1616261315),(233,25,24,1,3,'还是看不清楚',1616261368,1616261368,1616261368,1616261368,1616261368),(234,25,24,3,3,'{\"url\":\"http://156.245.19.199/uploads/images/20210321/QQ截图20210321002924.png\",\"w\":1324,\"h\":92}',1616261373,1616261374,1616261373,1616261374,1616261374),(235,24,25,1,3,'Enter主要用于换行\n在需要输入多行信息的场景下使用，发消息统一使用发送键\n',1616261377,1616261377,1616261377,1616261377,1616261377);
/*!40000 ALTER TABLE `df_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_message_group`
--

DROP TABLE IF EXISTS `df_message_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_message_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '群组ID',
  `send_mid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '发送方会员ID',
  `to_mid` text NOT NULL COMMENT '@会员ID,如1,2,3...',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '消息类型:1-文本|2-语音|3-图片|5-视频',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '消息状态',
  `content` text CHARACTER SET utf8mb4 NOT NULL COMMENT '消息内容',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  `send_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '发送时间',
  `receive_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收到时间',
  `read_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '读取时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_message_group`
--

LOCK TABLES `df_message_group` WRITE;
/*!40000 ALTER TABLE `df_message_group` DISABLE KEYS */;
INSERT INTO `df_message_group` VALUES (1,2,0,'',1,1,'创建成功',1614509796,1614509796,1614509796,0,0),(2,2,0,'',1,1,'95599加入',1614509859,1614509859,1614509859,0,0),(3,2,2,'',3,1,'{\"url\":\"http://156.245.19.199/uploads/images/20210228/chkdpgdpnlv.png\",\"w\":300,\"h\":249}',1614514510,1614514510,1614514510,0,0),(4,2,2,'',3,1,'{\"url\":\"http://156.245.19.199/uploads/images/20210228/tb.png\",\"w\":225,\"h\":225}',1614514544,1614514544,1614514544,0,0),(5,2,2,'',1,1,'1',1614514672,1614514672,1614514672,0,0),(6,2,2,'',1,1,'2',1614514677,1614514677,1614514677,0,0),(7,2,2,'',1,1,'3',1614514701,1614514701,1614514701,0,0),(8,2,2,'',1,1,'1',1614514841,1614514841,1614514841,0,0),(9,2,2,'',1,1,'2',1614515081,1614515081,1614515081,0,0),(10,2,2,'',3,1,'{\"url\":\"http://156.245.19.199/uploads/images/20210228/chkdpgdpnlv.png\",\"w\":300,\"h\":249}',1614515321,1614515321,1614515321,0,0),(11,2,2,'',1,1,'ok',1614515358,1614515358,1614515358,0,0),(12,2,2,'',1,1,'1',1614516452,1614516452,1614516452,0,0),(13,2,2,'',1,1,'2',1614516586,1614516586,1614516586,0,0),(14,2,2,'',1,1,'3',1614516799,1614516799,1614516799,0,0),(15,2,2,'',1,1,'a\nb\nc',1614516832,1614516832,1614516832,0,0),(16,3,0,'',1,1,'创建成功',1614516902,1614516902,1614516902,0,0),(17,4,0,'',1,1,'创建成功',1614517449,1614517449,1614517449,0,0),(18,2,2,'',5,1,'{\"url\":\"http://156.245.19.199/uploads/videos/20210302/WhatsApp Video 2021-02-28 at 9.14.09 PM.mp4\",\"w\":720,\"h\":1600}',1614658434,1614658434,1614658434,0,0),(19,2,2,'',5,1,'{\"url\":\"http://156.245.19.199/uploads/videos/20210302/WhatsApp Video 2021-02-28 at 9.14.09 PM.mp4\",\"w\":720,\"h\":1600}',1614658557,1614658557,1614658557,0,0),(23,2,2,'',5,1,'{\"url\":\"http://156.245.19.199/uploads/videos/20210302/WhatsApp Video 2021-02-28 at 9.14.09 PM.mp4\",\"w\":720,\"h\":1600}',1614661061,1614661061,1614661061,0,0),(25,2,2,'',1,1,'ok',1614661826,1614661826,1614661826,0,0),(26,2,2,'',1,1,'o\nj\nb\nk',1614661834,1614661834,1614661834,0,0),(27,2,0,'',1,1,'ATM666加入',1614770737,1614770737,1614770737,0,0),(28,2,2,'',1,1,'你好',1615633500,1615633500,1615633500,0,0),(29,2,3,'',1,1,'你好',1615633519,1615633519,1615633519,0,0),(30,2,2,'',1,1,'1',1615633603,1615633603,1615633603,0,0),(31,2,2,'',1,1,'2',1615633661,1615633661,1615633661,0,0),(32,2,2,'',1,1,'3',1615634297,1615634297,1615634297,0,0),(33,2,3,'',1,1,'哈哈😃',1615634317,1615634317,1615634317,0,0),(34,2,3,'',1,1,'<img src=\"https://s2.ax1x.com/2019/04/12/AbNQgA.gif\"><img src=\"https://s2.ax1x.com/2019/04/12/AbNwgs.gif\">',1615731131,1615731131,1615731131,0,0),(35,2,2,'',1,1,'yes',1615734949,1615734949,1615734949,0,0),(36,2,2,'',1,1,'还有人在吗',1615737834,1615737834,1615737834,0,0),(37,2,3,'',1,1,'有🈶',1615995875,1615995875,1615995875,0,0),(38,5,0,'',1,1,'创建成功',1616171313,1616171313,1616171313,0,0),(39,5,0,'',1,1,'ceshi009加入',1616171378,1616171378,1616171378,0,0),(40,9,0,'',1,1,'创建成功',1616171729,1616171729,1616171729,0,0),(41,10,0,'',1,1,'创建成功',1616172773,1616172773,1616172773,0,0),(42,11,0,'',1,1,'创建成功',1616173005,1616173005,1616173005,0,0),(43,2,2,'',1,1,'2',1616173112,1616173112,1616173112,0,0),(44,5,2,'',1,1,'大家好',1616246100,1616246100,1616246100,0,0),(45,5,7,'',1,1,'你好<img src=\"https://s2.ax1x.com/2019/04/12/AbNQgA.gif\">',1616246149,1616246149,1616246149,0,0),(46,5,0,'',1,1,'10086被移出',1616246245,1616246245,1616246245,0,0),(47,5,7,'',1,1,'ok',1616247063,1616247063,1616247063,0,0),(48,5,23,'',1,1,'9',1616257047,1616257047,1616257047,0,0),(49,5,0,'',1,1,'客服02加入',1616257157,1616257157,1616257157,0,0),(50,9,0,'',1,1,'客服02加入',1616257175,1616257175,1616257175,0,0);
/*!40000 ALTER TABLE `df_message_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_note`
--

DROP TABLE IF EXISTS `df_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_note` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '标题',
  `content` text CHARACTER SET utf8mb4 NOT NULL COMMENT '内容',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统公告';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_note`
--

LOCK TABLES `df_note` WRITE;
/*!40000 ALTER TABLE `df_note` DISABLE KEYS */;
INSERT INTO `df_note` VALUES (1,'北京桔桔网络科技有限公司工商登记信息','<p style=\"margin-left:0px; margin-right:0px; text-align:start\"><span style=\"font-size:12px\"><span style=\"color:#000000\"><span style=\"font-family:&quot;sans serif&quot;,tahoma,verdana,helvetica\">尊贵的用户您好，桔桔惠生活-----最信赖的广告发布、产品策划、代理平台。</span></span></span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\"><span style=\"font-size:12px\"><span style=\"color:#000000\"><span style=\"font-family:&quot;sans serif&quot;,tahoma,verdana,helvetica\">公司营业执照统一社会信用代码：91110105MA00DGL133</span></span></span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\"><span style=\"font-size:12px\"><span style=\"color:#000000\"><span style=\"font-family:&quot;sans serif&quot;,tahoma,verdana,helvetica\">可登陆国家企业信用信息公示系统进行查询：</span></span></span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\"><span style=\"font-size:12px\"><span style=\"color:#000000\"><span style=\"font-family:&quot;sans serif&quot;,tahoma,verdana,helvetica\">http://www.gsxt.gov.cn/index.html</span></span></span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\"><span style=\"font-size:12px\"><span style=\"color:#000000\"><span style=\"font-family:&quot;sans serif&quot;,tahoma,verdana,helvetica\">公司名字：北京桔桔网络科技有限公司</span></span></span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\"><span style=\"font-size:12px\"><span style=\"color:#000000\"><span style=\"font-family:&quot;sans serif&quot;,tahoma,verdana,helvetica\">法人代表：王伦</span></span></span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\"><span style=\"font-size:12px\"><span style=\"color:#000000\"><span style=\"font-family:&quot;sans serif&quot;,tahoma,verdana,helvetica\">注册资本：&nbsp;&nbsp;&nbsp; 300万(元)</span></span></span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\"><span style=\"font-size:12px\"><span style=\"color:#000000\"><span style=\"font-family:&quot;sans serif&quot;,tahoma,verdana,helvetica\">工商注册号：110105023278138</span></span></span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\"><span style=\"font-size:12px\"><span style=\"color:#000000\"><span style=\"font-family:&quot;sans serif&quot;,tahoma,verdana,helvetica\">登记机关：北京市工商行政管理局朝阳分局</span></span></span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\"><span style=\"font-size:12px\"><span style=\"color:#000000\"><span style=\"font-family:&quot;sans serif&quot;,tahoma,verdana,helvetica\">成立时间：2017年4月13日</span></span></span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\"><span style=\"font-size:12px\"><span style=\"color:#000000\"><span style=\"font-family:&quot;sans serif&quot;,tahoma,verdana,helvetica\">公司地址：北京市朝阳区霄云路21号1幢三层（麦子店孵化器01276号）</span></span></span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\"><span style=\"font-size:12px\"><span style=\"color:#000000\"><span style=\"font-family:&quot;sans serif&quot;,tahoma,verdana,helvetica\">&nbsp;</span></span></span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\"><span style=\"font-size:12px\"><span style=\"color:#000000\"><span style=\"font-family:&quot;sans serif&quot;,tahoma,verdana,helvetica\">成立至今，已发展成为集品牌策划代理、广告代理发布、广告创意制作于一体的专业化广告公司。本公司致力于以睿智的策划、独到的创意、精心的制作和高效的平台为客户提供所信赖和注重效益的服务。我公司与多家零售商和代理商建立了长期稳定的合作关系，品种齐全、价格合理，企业实力雄厚，重信用、守合同、保证产品质量，以多品种经营特色和薄利多销的原则，赢得了广大客户的信任，公司始终奉行&ldquo;诚信求实、致力服务、唯求满意&rdquo;的企业宗旨，全力跟随客户需求，不断进行产品创新和服务改进。</span></span></span></p>\r\n',0,1615987696,1615988282),(2,'第三方维权监管[官方通告]','<p>第三方维权监管[官方通告]：交易人数众多，交易笔数过大，若在交易过程中，忘记截图保存转账成功凭据，或因个人马虎写错收款银行卡号等信息，导致未能及时收到转款成功的会员，可向本第三方维权监管官方，申请协助，我们将尽快帮助你处理完成转款事宜！</p>\r\n',0,1615988444,1615988444),(3,'工作时间通知','<p>工作时间通知:本平台系统工作时间为中午1点&rarr;晚上凌晨1点，所有抢单&rarr;充值&rarr;提现，请在工作时间内操作，谢谢配合！</p>\r\n',0,1615988479,1615988479);
/*!40000 ALTER TABLE `df_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_read_group_msg`
--

DROP TABLE IF EXISTS `df_read_group_msg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_read_group_msg` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0',
  `group_msg_id` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(2) NOT NULL DEFAULT '0',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`,`group_msg_id`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=138 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_read_group_msg`
--

LOCK TABLES `df_read_group_msg` WRITE;
/*!40000 ALTER TABLE `df_read_group_msg` DISABLE KEYS */;
INSERT INTO `df_read_group_msg` VALUES (1,2,2,1,3,1614509808,1614509808),(2,1,2,2,3,1614509882,1614509882),(3,1,2,1,3,1614509882,1614509882),(4,2,2,2,3,1614509896,1614509896),(5,1,2,3,3,1614514524,1614514524),(6,2,2,3,3,1614514528,1614514528),(7,2,2,4,3,1614514609,1614514609),(8,2,2,6,3,1614514694,1614514694),(9,2,2,5,3,1614514694,1614514694),(10,2,2,7,3,1614514788,1614514788),(11,2,2,8,3,1614515078,1614515078),(12,2,2,11,3,1614516443,1614516443),(13,2,2,10,3,1614516443,1614516443),(14,2,2,9,3,1614516443,1614516443),(15,2,2,12,3,1614516573,1614516573),(16,2,2,13,3,1614516786,1614516786),(17,2,2,14,3,1614516800,1614516800),(18,2,2,15,3,1614516832,1614516832),(19,2,2,18,3,1614658434,1614658434),(20,2,2,19,3,1614658557,1614658557),(21,2,2,20,3,1614659559,1614659559),(22,2,2,21,3,1614659899,1614659899),(23,2,2,22,3,1614660731,1614660731),(24,2,2,23,3,1614661061,1614661061),(25,2,2,24,3,1614661814,1614661814),(26,2,2,25,3,1614661826,1614661826),(27,2,2,26,3,1614661834,1614661834),(28,3,4,17,3,1614665205,1614665205),(29,2,3,16,3,1614665771,1614665771),(30,1,2,26,3,1614689873,1614689873),(31,1,2,25,3,1614689873,1614689873),(32,1,2,24,3,1614689873,1614689873),(33,1,2,23,3,1614689873,1614689873),(34,1,2,22,3,1614689873,1614689873),(35,1,2,21,3,1614689873,1614689873),(36,1,2,20,3,1614689873,1614689873),(37,1,2,19,3,1614689873,1614689873),(38,1,2,18,3,1614689873,1614689873),(39,1,2,15,3,1614689873,1614689873),(40,2,2,27,3,1614770741,1614770741),(41,3,2,27,3,1614771248,1614771248),(42,3,2,26,3,1614771248,1614771248),(43,3,2,25,3,1614771248,1614771248),(44,3,2,23,3,1614771248,1614771248),(45,3,2,22,3,1614771248,1614771248),(46,3,2,21,3,1614771248,1614771248),(47,3,2,20,3,1614771248,1614771248),(48,3,2,19,3,1614771248,1614771248),(49,3,2,18,3,1614771248,1614771248),(50,3,2,15,3,1614771248,1614771248),(51,3,2,14,3,1614772597,1614772597),(52,3,2,13,3,1614772597,1614772597),(53,3,2,12,3,1614772597,1614772597),(54,3,2,11,3,1614772597,1614772597),(55,3,2,10,3,1614772597,1614772597),(56,3,2,9,3,1614772597,1614772597),(57,3,2,8,3,1614772597,1614772597),(58,3,2,7,3,1614772597,1614772597),(59,3,2,6,3,1614772597,1614772597),(60,3,2,5,3,1614772597,1614772597),(61,3,2,4,3,1614772598,1614772598),(62,3,2,3,3,1614772598,1614772598),(63,3,2,2,3,1614772598,1614772598),(64,3,2,1,3,1614772598,1614772598),(65,2,2,28,3,1615633500,1615633500),(66,3,2,28,3,1615633500,1615633500),(67,2,2,29,3,1615633519,1615633519),(68,3,2,29,3,1615633519,1615633519),(69,2,2,30,3,1615633603,1615633603),(70,3,2,30,3,1615633603,1615633603),(71,2,2,31,3,1615633661,1615633661),(72,3,2,31,3,1615633662,1615633662),(73,2,2,32,3,1615634297,1615634297),(74,3,2,32,3,1615634309,1615634309),(75,2,2,33,3,1615634318,1615634318),(76,3,2,33,3,1615634318,1615634318),(77,3,2,34,3,1615731131,1615731131),(78,2,2,34,3,1615734912,1615734912),(79,2,2,35,3,1615734949,1615734949),(80,3,2,35,3,1615735045,1615735045),(81,2,2,36,3,1615737834,1615737834),(82,3,2,36,3,1615737834,1615737834),(83,3,2,37,3,1615995875,1615995875),(84,2,2,37,3,1615996066,1615996066),(85,7,5,38,3,1616171334,1616171334),(86,7,5,39,3,1616171385,1616171385),(87,14,5,39,3,1616171386,1616171386),(88,14,5,38,3,1616171386,1616171386),(89,7,9,40,3,1616171738,1616171738),(90,2,10,41,3,1616172789,1616172789),(91,2,2,43,3,1616173112,1616173112),(92,2,11,42,3,1616173126,1616173126),(93,11,5,39,3,1616229104,1616229104),(94,11,5,38,3,1616229104,1616229104),(95,2,5,39,3,1616230140,1616230140),(96,2,5,38,3,1616230140,1616230140),(97,2,5,44,3,1616246100,1616246100),(98,7,5,44,3,1616246143,1616246143),(99,7,5,45,3,1616246149,1616246149),(100,7,5,46,3,1616246263,1616246263),(101,7,5,47,3,1616247063,1616247063),(102,2,5,47,3,1616247067,1616247067),(103,2,5,46,3,1616247067,1616247067),(104,2,5,45,3,1616247067,1616247067),(105,3,2,43,3,1616249344,1616249344),(106,11,5,47,3,1616251544,1616251544),(107,11,5,46,3,1616251544,1616251544),(108,11,5,45,3,1616251544,1616251544),(109,11,5,44,3,1616251544,1616251544),(110,23,5,47,3,1616257039,1616257039),(111,23,5,46,3,1616257039,1616257039),(112,23,5,45,3,1616257039,1616257039),(113,23,5,44,3,1616257039,1616257039),(114,23,5,39,3,1616257039,1616257039),(115,23,5,38,3,1616257039,1616257039),(116,23,5,48,3,1616257047,1616257047),(117,7,5,48,3,1616257116,1616257116),(118,23,5,49,3,1616257210,1616257210),(119,7,5,49,3,1616257714,1616257714),(120,13,5,49,3,1616257748,1616257748),(121,13,5,48,3,1616257748,1616257748),(122,13,5,47,3,1616257748,1616257748),(123,13,5,46,3,1616257748,1616257748),(124,13,5,45,3,1616257748,1616257748),(125,13,5,44,3,1616257748,1616257748),(126,13,5,39,3,1616257748,1616257748),(127,13,5,38,3,1616257748,1616257748),(128,24,5,49,3,1616257885,1616257885),(129,24,5,48,3,1616257885,1616257885),(130,24,5,47,3,1616257885,1616257885),(131,24,5,46,3,1616257885,1616257885),(132,24,5,45,3,1616257885,1616257885),(133,24,5,44,3,1616257885,1616257885),(134,24,5,39,3,1616257885,1616257885),(135,24,5,38,3,1616257885,1616257885),(136,2,5,49,3,1616258223,1616258223),(137,2,5,48,3,1616258223,1616258223);
/*!40000 ALTER TABLE `df_read_group_msg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_socket_client`
--

DROP TABLE IF EXISTS `df_socket_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_socket_client` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(10) unsigned NOT NULL DEFAULT '0',
  `fd` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fd` (`fd`) USING HASH COMMENT '仅支持"=","IN"和"<=>"查询'
) ENGINE=InnoDB AUTO_INCREMENT=2760 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_socket_client`
--

LOCK TABLES `df_socket_client` WRITE;
/*!40000 ALTER TABLE `df_socket_client` DISABLE KEYS */;
INSERT INTO `df_socket_client` VALUES (2739,1,16,7),(2748,1,25,24),(2756,1,33,2),(2757,1,34,13),(2758,1,36,25),(2759,1,37,13);
/*!40000 ALTER TABLE `df_socket_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_system_config`
--

DROP TABLE IF EXISTS `df_system_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_system_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_agreement` text CHARACTER SET utf8mb4 NOT NULL COMMENT '用户协议',
  `privacy_policy` text CHARACTER SET utf8mb4 NOT NULL COMMENT '隐私条款',
  `welcome` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '问候语',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_system_config`
--

LOCK TABLES `df_system_config` WRITE;
/*!40000 ALTER TABLE `df_system_config` DISABLE KEYS */;
INSERT INTO `df_system_config` VALUES (1,' <view>\r\n            \r\n          1.特别提示<br>\r\n          \r\n          1.1为了更好地为您提供服务，请您仔细阅读这份协议。本协议是您与本应用就您登录本应用平台进行注册及使用等所涉及的全部行为所订立的权利义务规范。您在注册过程中点击“注册”等按钮、及注册后登录和使用时，均表明您已完全同意并接受本协议，愿意遵守本协议的各项规则、规范的全部内容，若不同意则可停止注册或使用本应用平台。如您是未成年人，您还应要求您的监护人仔细阅读本协议，并取得他/他们的同意。\r\n          <br>\r\n          1.2为提高用户的使用感受和满意度，用户同意本应用将基于用户的操作行为对用户数据进行调查研究和分析，从而进一步优化服务。\r\n            \r\n            \r\n        </view>\r\n        <view>\r\n         2.服务内容\r\n         <br>\r\n         2.1本APP是一个真人社交应用平台，平台内严禁一切非法、涉黄信息，违反社区运营规范者，一律封号处理。\r\n         <br>\r\n         2.2本应用服务的具体内容由本应用制作者根据实际情况提供。\r\n         <br>\r\n          2.3 除非本注册及服务协议另有其它明示规定，本应用所推出的新产品、新功能、新服务，均受到本注册及注册协议规范。n2.4 本应用仅提供相关的网络服务，除此之外与相关网络服务有关的设备(如个人电脑、手机、及其他与接入互联网或移动网有关的装置)及所需的费用(如为接入互联网而支付的电话费及上网费、为使用移动网而支付的手机费)均应由用户自行负担。\r\n            \r\n            \r\n            \r\n        </view>\r\n        <view>\r\n            3.使用规则\r\n            <br>\r\n            3.1 用户帐号注册\r\n            <br>\r\n            3.1.1使用本应用系统注册的用户，只能使用汉字、英文字母、数字、下划线及它们的组合，禁止使用空格、各种符号和特殊字符，且最多不超过16个字符(8个汉字)注册，否则将不予注册。\r\n            <br>\r\n            3.1.2使用第三方合作网站登录的用户，只能使用汉字、英文字母、数字、下划线及它们的组合，禁止使用空格、各种符号和特殊字符，且最多不超过14个字符(7个汉字)注册，否则本社区有权只截取前14个字符（7个汉字）予以显示用户帐号（若该用户帐号与应用现有用户帐号重名，系统将随机添加一个字符以示区别），否则将不予注册。\r\n            <br>\r\n            3.2如发现用户帐号中含有不雅文字或不恰当名称的，心动保留取消其用户资格的权利。\r\n            <br>\r\n            3.2.1请勿以党和国家领导人或其他社会名人的真实姓名、字号、艺名、笔名注册；\r\n            <br>\r\n            3.2.2请勿以国家机构或其他机构的名称注册；\r\n            <br>\r\n            3.2.3请勿注册不文明、不健康名字，或包含歧视、侮辱、猥亵类词语的帐号；\r\n            <br>\r\n            3.2.4请勿注册易产生歧义、引起他人误解或其它不符合法律规定的帐号。\r\n            <br>\r\n            3.3用户帐号的所有权归本应用，用户仅享有使用权。\r\n            <br>\r\n            3.4用户有义务保证密码和帐号的安全，用户利用该密码和帐号所进行的一切活动引起的任何损失或损害，由用户自行承担全部责任，本应用不承担任何责任。如用户发现帐号遭到未授权的使用或发生其他任何安全问题，应立即修改帐号密码并妥善保管，如有必要，请反馈通知本应用管理人员。因黑客行为或用户的保管疏忽导致帐号非法使用，本应用不承担任何责任。\r\n            <br>\r\n            3.5 用户承诺对其发表或者上传于本应用的所有信息(即属于《中华人民共和国著作权法》规定的作品，包括但不限于文字、图片、音乐、电影、表演和录音录像制品和电脑程序等)均享有完整的知识产权，或者已经得到相关权利人的合法授权；如用户违反本条规定造成本应用被第三人索赔的，用户应全额补偿本应用的一切费用(包括但不限于各种赔偿费、诉讼代理费及为此支出的其它合理费用)；\r\n            <br>\r\n            3.6当第三方认为用户发表或者上传于本应用的信息侵犯其权利，并根据《信息网络传播权保护条例》或者相关法律规定向本应用发送权利通知书时，用户同意本应用可以自行判断决定删除涉嫌侵权信息，除非用户提交书面证据材料排除侵权的可能性，本应用将不会自动恢复上述删除的信息；\r\n            <br>\r\n            (1)不得为任何非法目的而使用网络服务系统；\r\n            <br>\r\n            (2)遵守所有与网络服务有关的网络协议、规定和程序；\r\n            <br>\r\n            (3)不得利用本应用的服务进行任何可能对互联网的正常运转造成不利影响的行为；\r\n            <br>\r\n            (4)不得利用本应用服务进行任何不利于本应用的行为。\r\n            <br>\r\n            3.7如用户在使用网络服务时违反上述任何规定，本应用有权要求用户改正或直接采取一切必要的措施(包括但不限于删除用户上传的内容、暂停或终止用户使用网络服务的权利)以减轻用户不当行为而造成的影响。\r\n            \r\n            \r\n            \r\n            \r\n        </view>\r\n        <view>\r\n            4.责任声明\r\n            <br>\r\n            4.1 任何网站、单位或者个人如认为本应用或者本应用提供的相关内容涉嫌侵犯其合法权益，应及时向本应用提供书面权力通知，并提供身份证明、权属证明及详细侵权情况证明。本应用在收到上述法律文件后，将会尽快切断相关内容以保证相关网站、单位或者个人的合法权益得到保障。\r\n            <br>\r\n            4.2用户明确同意其使用本应用网络服务所存在的风险及一切后果将完全由用户本人承担，本应用对此不承担任何责任。\r\n           <br> \r\n            4.3本应用无法保证网络服务一定能满足用户的要求，也不保证网络服务的及时性、安全性、准确性。\r\n            <br>\r\n            4.4本应用不保证为方便用户而设置的外部链接的准确性和完整性，同时，对于该等外部链接指向的不由本应用实际控制的任何网页上的内容，本应用不承担任何责任。\r\n            \r\n            \r\n            \r\n        </view>\r\n        <view>\r\n            \r\n            5.知识产权\r\n            <br>\r\n            5.1 本应用特有的标识、版面设计、编排方式等版权均属本应用享有，未经本应用许可授权，不得任意复制或转载。\r\n            <br>\r\n            5.2 用户从本应用的服务中获得的信息，未经本应用的许可，不得任意复制或转载。\r\n            <br>\r\n            5.3 本应用的所有内容，包括商品描述、图片等内容所有权归属于本APP的用户，任何人不得转载。\r\n            <br>\r\n            5.4 本应用所有用户上传内容仅代表用户自己的立场和观点，与本应用无关，由作者本人承担一切法律责任。\r\n            <br>\r\n            5.5上述及其他任何本服务包含的内容的知识产权均受到法律保护，未经本应用、用户或相关权利人书面许可，任何人不得以任何形式进行使用或创造相关衍生作品。\r\n            \r\n            \r\n        </view>\r\n        <view>\r\n            \r\n         6.隐私保护\r\n         <br>\r\n         6.1 本应用不对外公开或向第三方提供单个用户的注册资料及用户在使用网络服务时存储在本社区的非公开内容，但下列情况除外：\r\n         <br>\r\n         (1)事先获得用户的明确授权；\r\n         <br>\r\n         (2)根据有关的法律法规要求；\r\n         <br>\r\n         (3)按照相关政府主管部门的要求；\r\n         <br>\r\n         (4)为维护社会公众的利益。\r\n         <br>\r\n         6.2 本应用可能会与第三方合作向用户提供相关的网络服务，在此情况下，如该第三方同意承担与本社区同等的保护用户隐私的责任，则本社区有权将用户的注册资料等信息提供给该第三方，并无须另行告知用户。\r\n         <br>\r\n         6.3 在不透露单个用户隐私资料的前提下，本应用有权对整个用户数据库进行分析并对用户数据库进行商业上的利用。\r\n            \r\n            \r\n        </view>\r\n        <view>\r\n            \r\n            7.协议修改\r\n            <br>\r\n            7.1本应用有权随时修改本协议的任何条款，一旦本协议的内容发生变动，本应用将会在本应用上公布修改之后的协议内容，若用户不同意上述修改，则可以选择停止使用本应用。本应用也可选择通过其他适当方式（比如系统通知）向用户通知修改内容。\r\n            <br>\r\n            7.2如果不同意本应用对本协议相关条款所做的修改，用户有权停止使用本应用。如果用户继续使用本应用，则视为用户接受本应用对本协议相关条款所做的修改。\r\n            \r\n            \r\n            \r\n        </view>\r\n\r\n       <view>\r\n            8.联系我们<br>\r\n            \r\n            如果您有投诉、建议、疑问，请联系我们官方小助手。\r\n             \r\n        </view>','    \r\n		本应用尊重并保护所有使用服务用户的个人隐私权。为了给您提供更准确、更有个性化的服务，本应用会按照本隐私权政策的规定使用和披露您的个人信息。\r\n        但本应用将以高度的勤勉、审慎义务对待这些信息。<br>\r\n        除本隐私权政策另有规定外，在未征得您事先许可的情况下，本应用不会将这些信息对外披露或向第三方提供。本应用会不时更新本隐私权政策。 您在同意本应用服务使用协议之时，即视为您已经同意本隐私权政策全部内容。本隐私权政策属于本应用服务使用协议不可分割的一部分。\r\n		<br>\r\n       \r\n       <view>\r\n         1.适用范围<br>\r\n         (a)在您使用本应用时，我们可能会申请系统设备权限收集设备信息、日志信息，用于推送和安全风控，并申请存储权限，用于下载及缓存相关文件；<br>\r\n         (b)您使用发布视频、语音、图片等功能时候，我们会请求您授权相机、照片、麦克风的权限。您如果拒绝授权提供，将无法使用此功能，但不影响您使用本应用的其他功能。 <br>  \r\n         (c) 在您使用本应用网络服务，本应用自动接收并记录您的设备信息，包括但不限于您的IP地址、使用的语言、访问日期和时间、软硬件特征信息等数据；\r\n         <br>  \r\n         (d) 本应用通过合法途径从商业伙伴处取得的用户个人数据。<br>  \r\n         \r\n       </view>\r\n       \r\n       <view>\r\n2.您了解并同意，以下信息不适用本隐私权政策：<br>\r\n		\r\n		(a) 您在使用本应用平台提供的搜索服务时输入的关键字信息；<br>\r\n		\r\n		(b) 本应用收集到的您在本应用发布的有关信息数据，包括但不限于参与活动、成交信息及评价详情；<br>\r\n		\r\n		(c) 违反法律规定或违反本应用规则行为及本应用已对您采取的措施。<br>           \r\n           \r\n       </view>\r\n       \r\n       <view>\r\n           \r\n          \r\n          3.信息使用\r\n          (a)本应用不会向任何无关第三方提供、出售、出租、分享或交易您的个人信息，除非事先得到您的许可，或该第三方和本应用（含本应用关联公司）单独或共同为您提供服务，且在该服务结束后，其将被禁止访问包括其以前能够访问的所有这些资料。<br>\r\n          \r\n          (b) 本应用亦不允许任何第三方以任何手段收集、编辑、出售或者无偿传播您的个人信息。任何本应用平台用户如从事上述活动，一经发现，本应用有权立即终止与该用户的服务协议。<br>\r\n          \r\n          (c) 为服务用户的目的，本应用可能通过使用您的个人信息，向您提供您感兴趣的信息，包括但不限于向您发出产品和服务信息，或者与本应用合作伙伴共享信息以便他们向您发送有关其产品和服务的信息（后者需要您的事先同意）。<br>\r\n           \r\n       </view>\r\n       \r\n       <view>\r\n           4.信息披露<br>\r\n           在如下情况下，本应用将依据您的个人意愿或法律的规定全部或部分的披露您的个人信息：<br>\r\n           \r\n           (a) 经您事先同意，向第三方披露；<br>\r\n           \r\n           (b)为提供您所要求的产品和服务，而必须和第三方分享您的个人信息；<br>\r\n           \r\n           (c) 根据法律的有关规定，或者行政或司法机构的要求，向第三方或者行政、司法机构披露；<br>\r\n           \r\n           (d) 如您出现违反中国有关法律、法规或者本应用服务协议或相关规则的情况，需要向第三方披露；<br>\r\n           \r\n           (e) 如您是适格的知识产权投诉人并已提起投诉，应被投诉人要求，向被投诉人披露，以便双方处理可能的权利纠纷；<br>\r\n           \r\n           (f) 在本应用平台上创建的某一交易中，如交易任何一方履行或部分履行了交易义务并提出信息披露请求的，本应用有权决定向该用户提供其交易对方的联络方式等必要信息，以促成交易的完成或纠纷的解决。<br>\r\n           \r\n           (g) 其它本应用根据法律、法规或者网站政策认为合适的披露。<br>\r\n           \r\n           \r\n       </view>\r\n       \r\n       <view>\r\n           \r\n          5.信息存储和交换<br>\r\n          本应用收集的有关您的信息和资料将保存在本应用及（或）其关联公司的服务器上，这些信息和资料可能传送至您所在国家、地区或本应用收集信息和资料所在地的境外并在境外被访问、存储和展示。\r\n          <br>\r\n          6.Cookie的使用<br>\r\n          (a) 在您未拒绝接受cookies的情况下，本应用会在您的计算机上设定或取用cookies ，以便您能登录或使用依赖于cookies的本应用平台服务或功能。本应用使用cookies可为您提供更加周到的个性化服务，包括推广服务。\r\n          <br>\r\n          (b) 您有权选择接受或拒绝接受cookies。您可以通过修改浏览器设置的方式拒绝接受cookies。但如果您选择拒绝接受cookies，则您可能无法登录或使用依赖于cookies的本应用网络服务或功能。\r\n          <br>\r\n          (c) 通过本应用所设cookies所取得的有关信息，将适用本政策。 \r\n       </view>\r\n       <view>\r\n           \r\n         6.信息安全<br>\r\n         (a) 本应用帐号均有安全保护功能，请妥善保管您的用户名及密码信息。本应用将通过对用户密码进行加密等安全措施确保您的信息不丢失，不被滥用和变造。尽管有前述安全措施，但同时也请您注意在信息网络上不存在“完善的安全措施”。\r\n         <br>\r\n         (b) 在使用本应用网络服务进行网上交易时，您不可避免的要向交易对方或潜在的交易对  \r\n       </view>\r\n       <view>\r\n          7.本隐私政策的更改<br>\r\n          \r\n          (a)如果决定更改隐私政策，我们会在本政策中、本公司网站中以及我们认为适当的位置发布这些更改，以便您了解我们如何收集、使用您的个人信息，哪些人可以访问这些信息，以及在什么情况下我们会透露这些信息。\r\n          <br>\r\n          (b)本公司保留随时修改本政策的权利，因此请经常查看。如对本政策作出重大更改，本公司会通过通知的形式告知。\r\n          <br>\r\n          方披露自己的个人信息，如联络方式或者邮政地址。请您妥善保护自己的个人信息，仅在必要的情形下向他人提供。如您发现自己的个人信息泄密，尤其是本应用用户名及密码发生泄露，请您立即联络本应用客服，以便本应用采取相应措施。\r\n           \r\n           \r\n       </view>\r\n <view>\r\n          8.联系我们<br>\r\n          \r\n          如果您对个人信息保护问题有投诉、建议、疑问，请联系我们官方小助手。\r\n           \r\n       </view>','一小时日赚600-800！赶快下载APP赚钱！免费注册?客服马上带您日赚3000-5000元',1616072133,1616131612);
/*!40000 ALTER TABLE `df_system_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `df_third_link`
--

DROP TABLE IF EXISTS `df_third_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `df_third_link` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `df_third_link`
--

LOCK TABLES `df_third_link` WRITE;
/*!40000 ALTER TABLE `df_third_link` DISABLE KEYS */;
INSERT INTO `df_third_link` VALUES (1,'惠生活','http://43.255.29.177/',1614165153,1616217315);
/*!40000 ALTER TABLE `df_third_link` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-21  1:30:02
